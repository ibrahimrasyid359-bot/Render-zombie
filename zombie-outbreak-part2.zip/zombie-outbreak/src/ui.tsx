import React, {useEffect, useState} from 'react';
import {AbsoluteFill, continueRender, delayRender, interpolate, spring, useCurrentFrame} from 'remotion';
import {CHUNKS} from './script';
import type {Chunk} from './timeline';
import {FPS} from './config';
import {FONT, loaded} from './fonts';

export const FontGate: React.FC<{children: React.ReactNode}> = ({children}) => {
  const [ready, setReady] = useState(false);
  const [h] = useState(() => delayRender('font'));
  useEffect(() => { loaded.waitUntilDone().then(() => { setReady(true); continueRender(h); }).catch(() => { setReady(true); continueRender(h); }); }, [h]);
  return ready ? <>{children}</> : null;
};

export const Cinema: React.FC<{frame: number; vig?: number; tint?: string}> = ({frame, vig = 0.55, tint}) => (
  <>
    {tint && <AbsoluteFill style={{background: tint, mixBlendMode: 'multiply'}} />}
    <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,${vig}) 100%)`}} />
    <AbsoluteFill style={{backdropFilter: 'blur(5px)', WebkitMaskImage: 'linear-gradient(to bottom,#000 0%,transparent 14%,transparent 86%,#000 100%)', maskImage: 'linear-gradient(to bottom,#000 0%,transparent 14%,transparent 86%,#000 100%)'}} />
    <AbsoluteFill style={{opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width="100%" height="100%"><filter id={`n${frame % 6}`}><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed={frame % 6} /></filter><rect width="100%" height="100%" filter={`url(#n${frame % 6})`} /></svg>
    </AbsoluteFill>
  </>
);

export const Subtitles: React.FC<{chunks?: Chunk[]}> = ({chunks = CHUNKS as Chunk[]}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  let idx = -1;
  for (let i = 0; i < chunks.length; i++) if (chunks[i].start - 0.03 <= t) idx = i; else break;
  if (idx < 0) return null;
  const c = chunks[idx];
  if (t > c.end + 0.45) return null;
  const s = spring({frame: frame - Math.round(c.start * FPS), fps: FPS, config: {damping: 12, stiffness: 220, mass: 0.6}});
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 330}}>
      <div style={{width: 940, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '4px 16px', transform: `scale(${0.82 + 0.18 * s})`, opacity: Math.min(1, s * 1.5)}}>
        {c.words.map((w, i) => {
          const active = t >= w.start - 0.02 && t < w.end;
          return (
            <span key={i} style={{fontFamily: FONT, fontWeight: 900, fontSize: 82, lineHeight: 1.1, textTransform: 'uppercase', color: active ? '#FFE14D' : '#fff', WebkitTextStroke: '12px #000', paintOrder: 'stroke fill', textShadow: '0 6px 18px rgba(0,0,0,.6)', transform: active ? 'scale(1.08)' : 'none', display: 'inline-block'}}>
              {w.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

const Btn: React.FC<{f: number; start: number; k: 'A' | 'B'; title: string; sub: string; colors: [string, string]; top: number}> = ({f, start, k, title, sub, colors, top}) => {
  const s = spring({frame: f - start, fps: FPS, config: {damping: 11, stiffness: 150}});
  if (f < start) return null;
  const pulse = 1 + Math.sin(f / 7) * 0.018;
  const shine = ((f - start) * 14) % 1400 - 300;
  return (
    <div style={{position: 'absolute', left: 90, top, width: 900, height: 290, borderRadius: 44, transform: `translateX(${(1 - s) * (k === 'A' ? -900 : 900)}px) scale(${pulse})`, background: `linear-gradient(135deg,${colors[0]},${colors[1]})`, border: '6px solid #fff', boxShadow: `0 0 ${40 + Math.sin(f / 6) * 15}px ${colors[0]}`, overflow: 'hidden', display: 'flex', alignItems: 'center', padding: '0 50px', gap: 40}}>
      <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 210, color: '#fff', textShadow: '0 8px 0 rgba(0,0,0,.35)'}}>{k}</div>
      <div style={{flex: 1}}>
        <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 58, color: '#fff', lineHeight: 1.05}}>{title}</div>
        <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 36, color: 'rgba(255,255,255,.9)', marginTop: 12}}>{sub}</div>
      </div>
      <div style={{position: 'absolute', top: 0, bottom: 0, left: shine, width: 120, background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent)', transform: 'skewX(-20deg)'}} />
    </div>
  );
};

export const ChoiceUI: React.FC<{f: number; tTitle: number; tA: number; tB: number; tCta: number; tCta2: number; a?: {title: string; sub: string}; b?: {title: string; sub: string}; foot?: string}> = ({f, tTitle, tA, tB, tCta, tCta2, a = {title: 'RUMAH SAKIT', sub: 'Cari obat & asal wabah'}, b = {title: 'POS EVAKUASI', sub: 'Cari manusia yang bertahan'}, foot = 'Pilihan kalian menentukan kelanjutan Part 2.'}) => {
  const ts = spring({frame: f - tTitle, fps: FPS, config: {damping: 10, stiffness: 120}});
  const cs = spring({frame: f - tCta, fps: FPS, config: {damping: 9, stiffness: 140}});
  const c2 = interpolate(f, [tCta2, tCta2 + 12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const jit = f > tTitle ? Math.sin(f * 2.3) * 2 : 0;
  return (
    <AbsoluteFill>
      {f >= tTitle && (
        <div style={{position: 'absolute', top: 190, left: 0, right: 0, textAlign: 'center', fontFamily: FONT, fontWeight: 900, fontSize: 104, lineHeight: 1.05, color: '#fff', transform: `scale(${0.6 + 0.4 * ts}) translateX(${jit}px)`, opacity: ts, textShadow: '0 0 30px #c0261d, 0 6px 0 #7a1410', padding: '0 50px'}}>
          APA YANG<br /><span style={{color: '#ff3b30'}}>HARUS DILAKUKAN?</span>
        </div>
      )}
      <Btn f={f} start={tA} k="A" title={a.title} sub={a.sub} colors={['#d62b1f', '#6e100b']} top={500} />
      <Btn f={f} start={tB} k="B" title={b.title} sub={b.sub} colors={['#1f9d4b', '#0b4a22']} top={820} />
      {f >= tCta && (
        <div style={{position: 'absolute', top: 1150, left: 0, right: 0, textAlign: 'center'}}>
          <div style={{display: 'inline-block', background: '#FFE14D', color: '#111', fontFamily: FONT, fontWeight: 900, fontSize: 66, padding: '14px 44px', borderRadius: 24, transform: `scale(${0.7 + 0.3 * cs}) rotate(-2deg)`}}>KOMENTAR A ATAU B!</div>
          <div style={{marginTop: 26, opacity: c2, fontFamily: FONT, fontWeight: 800, fontSize: 40, color: '#fff', padding: '0 80px', textShadow: '0 4px 10px #000'}}>{foot}</div>
        </div>
      )}
    </AbsoluteFill>
  );
};
