import {FPS} from '../config';
import {buildTimeline} from '../timeline';
import lines from './lines2.json';
import captions from './captions2.json';
import timing from './timing2.json';
import {DURATION2} from './config2';

export const LINES2 = lines as {tag: string; text: string}[];
// Jika captions2.json terisi (npm run transcribe2), subtitle memakai kata hasil Whisper (sesuai suara asli).
export const TL2 = buildTimeline(LINES2, timing.audioSeconds, captions as any[], timing.lineStarts, true);
export const L2 = TL2.lineFrame; // frame awal tiap baris naskah
const mid = (a: number, b: number, k: number) => Math.round(L2(a) + (L2(b) - L2(a)) * k);

export type S2 = 'jalan' | 'gerbang' | 'lobi' | 'arsip' | 'lorong' | 'obat' | 'radio' | 'pilihan';
const marks: [S2, number][] = [
  ['jalan', 0], ['gerbang', L2(2)], ['lobi', mid(2, 3, 0.5)], ['arsip', L2(3)], ['lorong', L2(6)],
  ['obat', L2(7)], ['radio', L2(9)], ['pilihan', L2(11)],
];
export const SCENES2 = marks.map(([id, start], i) => ({id, start, end: i + 1 < marks.length ? marks[i + 1][1] : DURATION2}));
export const FPS2 = FPS;
