import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FPS} from '../config';
import {L2} from './script2';
import type {Key} from '../three/CameraRig';
import {World} from '../three/world';
import {Cinema, ChoiceUI} from '../ui';
import {Figure, PathFigure} from './figure3d';
import {Stage} from './stage';
import {Archive, Corridor, Hospital, KrlTrain, Lobby, Pharmacy} from './sets3d';

export type SP = {from: number; dur: number};
const ck = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], ck);
const inc = (a: number, b: number) => (a < b ? b : a + 1);
const useS = ({from, dur}: SP) => {
  const f = useCurrentFrame();
  const at = (i: number, off = 0) => L2(i) + Math.round(off * FPS) - from;
  return {f, dur, at};
};
// Karakter utama: SAMA di semua adegan (warna, proporsi, skala)
const HERO = {color: '#ffd166', scale: 0.7};
const Z = {zombie: true, scale: 0.7};
const dusk = {power: 0, day: 0.5, abandoned: 1, fogColor: '#8d968d', fogNear: 18, fogFar: 200, skipLeft: [-65, -27] as [number, number]};
const HZ = -46; // posisi rumah sakit di sepanjang jalan

const Street: React.FC<{f: number; focus: [number, number, number]; children: React.ReactNode}> = ({f, focus, children}) => (
  <World frame={f} focus={focus} {...dusk}>
    <Hospital frame={f} z={HZ} />
    <KrlTrain z={-22} />
    {children}
  </World>
);

/* 1. Perjalanan menuju rumah sakit (tracking shot) */
export const SceneJalan: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const zs = -10 - 1.9 * (dur / FPS);
  const keys: Key[] = [
    {f: 0, pos: [-3.6, 1.5, -3.5], look: [-9, 1.4, -14]},
    {f: dur, pos: [-3.6, 1.6, zs + 6.5], look: [-9.5, 2.6, zs - 5]},
  ];
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} linear sky={['#8c9690', '#b4bbb1']}>
        <Street f={f} focus={[-8.8, 0, -10 - (1.9 * f) / FPS]}>
          <PathFigure frame={f} path={[[-8.8, 0, -10], [-8.8, 0, -39]]} speed={1.9} pose="walk" hold="radio" emotion={f > 150 ? 'scared' : 'neutral'} {...HERO} />
          <Figure frame={f} pos={[-10.5, 0, -25.5]} yaw={0} pose="talk" emotion="scared" color="#7bdff2" scale={0.7} seed={1} />
          <Figure frame={f} pos={[-10.5, 0, -24]} yaw={Math.PI} pose="talk" emotion="sad" color="#ffadad" scale={0.7} seed={2} />
          <mesh position={[8.2, 0.45, -15]}><boxGeometry args={[1.0, 0.9, 1.8]} /><meshStandardMaterial color="#e6e8e6" roughness={0.5} /></mesh>
          <mesh position={[8.2, 1.1, -14.3]} rotation={[0.9, 0, 0]}><boxGeometry args={[1.0, 0.06, 0.9]} /><meshStandardMaterial color="#cfd2d0" /></mesh>
          <Figure frame={f} pos={[9.4, 0, -15]} yaw={-Math.PI / 2} pose="inspect" emotion="sad" color="#caffbf" scale={0.7} seed={3} />
          <PathFigure frame={f} path={[[5.5, 0, -45], [5.5, 0, -8]]} speed={4.2} loop phase={0.3} pose="run" emotion="panic" headYaw={2.6} color="#cdb4db" scale={0.7} />
          {[1.5, -2.5, 3.8, -4.5].map((x, i) => <PathFigure key={i} frame={f} path={[[x, 0, -62], [x, 0, -30]]} speed={0.9} loop phase={i * 0.23} pose="zombie" seed={i} {...Z} />)}
        </Street>
      </Stage>
      <Cinema frame={f} vig={0.5} tint="#d4d9cf" />
    </AbsoluteFill>
  );
};

/* 2. Gerbang rumah sakit */
export const SceneGerbang: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const keys: Key[] = [
    {f: 0, pos: [-4.5, 1.7, -31.5], look: [-11, 1.6, -41]},
    {f: dur, pos: [-6, 1.7, -41.5], look: [-15, 1.8, -46.5], fov: 46},
  ];
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} sky={['#8c9690', '#b4bbb1']}>
        <Street f={f} focus={[-12, 0, -44]}>
          <PathFigure frame={f} path={[[-8.8, 0, -39], [-8.8, 0, -45], [-12, 0, -45.5], [-16, 0, -46]]} speed={1.95} pose="walk" endPose="stand" endYaw={-Math.PI / 2}
            hold="radio" emotion={f > dur - 70 ? 'shock' : 'scared'} headYaw={0.5} {...HERO} />
          {[0, 1].map((i) => <PathFigure key={i} frame={f} path={[[-3 - i * 3, 0, -62], [-3 - i * 3, 0, -48]]} speed={0.7} pose="zombie" seed={i + 5} {...Z} />)}
        </Street>
      </Stage>
      <Cinema frame={f} vig={0.55} tint="#d4d9cf" />
    </AbsoluteFill>
  );
};

/* 3. Lobi: tulisan di dinding */
export const SceneLobi: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const keys: Key[] = [
    {f: 0, pos: [3.4, 1.7, 2.4], look: [-0.5, 1.6, -5]},
    {f: dur, pos: [1.3, 1.6, -0.4], look: [-1.2, 1.9, -7]},
  ];
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} lights amb={0.35} sky={['#0e0f0e', '#1a1c1a']} focus={[0, 1, -4]} fog={['#16181a', 8, 28]}>
        <Lobby frame={f} />
        <PathFigure frame={f} path={[[3.8, 0, -0.4], [0.6, 0, -5.3]]} speed={1.5} pose="walk" endPose="stand" endYaw={0.9} hold="radio" emotion="scared" headYaw={-0.9 * ramp(f, 80, 115)} {...HERO} />
      </Stage>
      <Cinema frame={f} vig={0.7} tint="#b9c2c2" />
    </AbsoluteFill>
  );
};

/* 4. Ruang arsip: catatan pasien nol */
export const SceneArsip: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const k1 = Math.max(60, at(4)), k2 = inc(k1, dur);
  const keys: Key[] = [
    {f: 0, pos: [3.5, 1.6, 1.5], look: [0, 1.4, -4.5]},
    {f: k1, pos: [2.0, 1.5, -0.6], look: [0, 1.5, -4.3], fov: 46},
    {f: k2, pos: [0.9, 1.5, -1.9], look: [0, 1.6, -4.2], fov: 40},
  ];
  const emo = f < at(4) ? 'confused' : f < at(5) ? 'shock' : 'scared';
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} lights amb={0.4} sky={['#12120f', '#201f1a']} focus={[0, 1, -4]} fog={['#1a1a16', 8, 26]}>
        <Archive frame={f} />
        <PathFigure frame={f} path={[[3.2, 0, -0.8], [0.3, 0, -4.2]]} speed={1.3} pose="walk" endPose="read" endYaw={0.25} hold="file" emotion={emo} {...HERO} />
      </Stage>
      <Cinema frame={f} vig={0.6} tint="#d8cdb0" />
    </AbsoluteFill>
  );
};

/* 5. Lorong: langkah diseret */
export const SceneLorong: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const keys: Key[] = [{f: 0, pos: [0, 1.6, 2.4], look: [0, 1.4, -12]}, {f: dur, pos: [0, 1.5, 0.8], look: [0, 1.4, -12], fov: 46}];
  const zOp = ramp(f, 20, dur - 20);
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} lights amb={0.22} sky={['#050605', '#0c0e0d']} focus={[0, 1, -8]} fog={['#0a0c0b', 4, 30]}>
        <Corridor frame={f} />
        <Figure frame={f} pos={[0.1, 0, -4.2]} yaw={0.15} pose="stand" emotion={f > dur * 0.6 ? 'panic' : 'scared'} headYaw={f > dur * 0.5 ? 0 : 0.5} {...HERO} />
        <PathFigure frame={f} path={[[0, 0, -26], [0, 0, -8]]} speed={1.35} pose="zombie" sil opacity={zOp} seed={2} {...Z} />
        <PathFigure frame={f} path={[[0.7, 0, -33], [0.7, 0, -14]]} speed={1.1} pose="zombie" sil opacity={zOp * 0.8} seed={4} {...Z} />
      </Stage>
      <Cinema frame={f} vig={0.8} tint="#a9b8b2" />
    </AbsoluteFill>
  );
};

/* 6. Ruang obat: pintu terkunci, kotak merah */
export const SceneObat: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const T2 = at(7, 3.0);
  const k1 = Math.max(30, at(8, -0.5)), k2 = inc(k1, at(8, 2.5)), k3 = inc(k2, dur);
  const keys: Key[] = [
    {f: 0, pos: [4.6, 1.5, 2.3], look: [-0.5, 1.2, -3.2]},
    {f: k1, pos: [3, 1.3, 0.6], look: [0.5, 1.0, -4.5]},
    {f: k2, pos: [1.9, 0.9, -2.9], look: [1.4, 0.5, -5.7], fov: 38},
    {f: k3, pos: [1.8, 0.85, -3.3], look: [1.4, 0.5, -5.7], fov: 34},
  ];
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} lights amb={0.35} sky={['#0d1110', '#1a2220']} focus={[0, 1, -3]} fog={['#141a18', 7, 22]}>
        <Pharmacy frame={f} />
        <PathFigure frame={f} path={[[3.6, 0, 0.2], [-2.4, 0, -2.0]]} speed={3.2} startFrame={at(7)} pose="run" endPose="stand" endYaw={-Math.PI / 2} emotion="panic" opacity={f < T2 ? 1 : 0} {...HERO} />
        <PathFigure frame={f} path={[[-2.4, 0, -2.0], [1.1, 0, -4.4]]} speed={1.8} startFrame={T2} hideBefore pose="sneak" endPose="crouch" endYaw={Math.PI - 0.9} emotion="scared" {...HERO} />
      </Stage>
      <Cinema frame={f} vig={0.65} tint="#b8cbc4" />
    </AbsoluteFill>
  );
};

/* 7. Radio berbunyi: "Kami tahu kamu di sana" */
export const SceneRadio: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const keys: Key[] = [
    {f: 0, pos: [1.2, 1.6, 0.4], look: [0.6, 1.5, -3.2], fov: 42},
    {f: dur, pos: [0.8, 1.55, -1.6], look: [0.6, 1.5, -3.2], fov: 30},
  ];
  const eyes = ramp(f, at(10, -0.5), at(10, 1.5));
  const black = ramp(f, dur - 24, dur);
  return (
    <AbsoluteFill>
      <Stage frame={f} keys={keys} lights amb={0.3} sky={['#0b0f0e', '#161d1b']} focus={[0.6, 1, -3]} fog={['#101614', 6, 20]}>
        <Pharmacy frame={f} box={0.3} />
        <Figure frame={f} pos={[0.6, 0, -3.0]} yaw={0} pose="holdradio" hold="radio" emotion={f > at(10) ? 'panic' : 'scared'} {...HERO} />
        <Figure frame={f} pos={[-2.5, 0, -5.4]} yaw={0} pose="zombie" sil opacity={eyes} seed={1} {...Z} />
        <Figure frame={f} pos={[-2.05, 0, -5.3]} yaw={0.15} pose="zombie" sil opacity={eyes * 0.8} seed={3} {...Z} />
      </Stage>
      <Cinema frame={f} vig={0.7} tint="#b8cbc4" />
      <AbsoluteFill style={{background: '#000', opacity: black}} />
    </AbsoluteFill>
  );
};

/* 8. Pilihan A / B */
export const ScenePilihan: React.FC<SP> = (sp) => {
  const {f, at} = useS(sp);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <ChoiceUI f={f} tTitle={at(11, 0.2)} tA={at(12)} tB={at(13)} tCta={at(14)} tCta2={at(15)}
        a={{title: 'AMBIL OBAT', sub: 'Lari sendirian'}} b={{title: 'BAWA KE POS', sub: 'Untuk yang bertahan'}} foot="Pilihan kalian menentukan Part 3." />
    </AbsoluteFill>
  );
};
