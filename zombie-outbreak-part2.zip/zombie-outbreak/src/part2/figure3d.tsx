import React, {useEffect, useMemo} from 'react';
import * as THREE from 'three';
import {FPS} from '../config';
import {Emotion, face} from '../stickman';

export type V3 = [number, number, number];
export type Pose3 = 'stand' | 'walk' | 'run' | 'zombie' | 'read' | 'handsup' | 'exhausted' | 'inspect' | 'talk' | 'holdradio' | 'crouch' | 'sneak';
const D = Math.PI / 180;
// panjang langkah per siklus (m) -> kecepatan siklus = kecepatan / STRIDE, supaya kaki tidak "meluncur"
export const STRIDE: Record<string, number> = {walk: 2.0, run: 2.97, zombie: 1.5, sneak: 1.1, exhausted: 1.2};

type Sol = {L: number[]; K: number[]; arms: number[][]; lean: number; twist: number; hp: number; hy: number; hr: number; hipY: number};
// sudut: kaki/lengan "maju" = positif. arms[i] = [pitch, roll(keluar), siku(menekuk ke depan)]
export function solve(pose: Pose3, t: number, cps: number, seed = 0): Sol {
  const p = t * cps * Math.PI * 2 + seed * 1.7;
  const br = Math.sin(t * 1.7 + seed);
  let lean = 0.03 + br * 0.012, twist = 0, hp = 0, hy = Math.sin(t * 0.6 + seed) * 0.12, hr = 0;
  const L = [0.04, -0.04], K = [0.02, 0.02];
  let arms: number[][] = [[0.05, 0.12, 0.12], [0.05, 0.12, 0.12]];
  const cyc = (A: number, B: number) => { for (let i = 0; i < 2; i++) { const ph = p + i * Math.PI; L[i] = Math.sin(ph) * A; K[i] = B * Math.max(0, Math.cos(ph)); } };
  switch (pose) {
    case 'walk':
      cyc(30 * D, 40 * D); lean = 0.06; twist = Math.sin(p) * 0.12;
      arms = [0, 1].map((i) => [-Math.sin(p + i * Math.PI) * 28 * D, 0.1, 0.25 + 0.2 * Math.max(0, Math.sin(p + i * Math.PI))]); break;
    case 'run':
      cyc(48 * D, 75 * D); lean = 0.22; twist = Math.sin(p) * 0.2;
      arms = [0, 1].map((i) => [-Math.sin(p + i * Math.PI) * 60 * D, 0.05, 1.4]); break;
    case 'sneak':
      cyc(16 * D, 30 * D); lean = 0.35; hp = 0.2; arms = [[0.3, 0.1, 0.6], [0.3, 0.1, 0.6]]; break;
    case 'zombie':
      L[0] = Math.sin(p) * 22 * D + 8 * D; K[0] = 25 * D * Math.max(0, Math.cos(p)); L[1] = -10 * D + Math.sin(p + Math.PI) * 10 * D; K[1] = 0.15;
      lean = 0.28; hp = 0.25; hr = 0.18 + Math.sin(t * 1.3 + seed) * 0.08; twist = Math.sin(p) * 0.15; hy = Math.sin(t * 0.9 + seed) * 0.25;
      arms = [[1.45 + Math.sin(p * 0.5) * 0.1, 0.15, 0.08], [1.35 + Math.sin(p * 0.5 + 2) * 0.1, 0.15, 0.08]]; break;
    case 'handsup': {
      const tr = Math.sin(t * 28) * 0.05; L[0] = -0.12; L[1] = 0.12; K[0] = K[1] = 0.15; lean = -0.05; hp = -0.1;
      arms = [[2.9 + tr, 0.35, 0.2], [2.9 - tr, 0.35, 0.2]]; break; }
    case 'read':
      lean = 0.12; hp = 0.5; arms = [[0.95, -0.1, 1.5], [0.95, -0.1, 1.5]]; break;
    case 'exhausted':
      lean = 0.32 + br * 0.03; hp = 0.45; L[0] = 0.14; L[1] = -0.04; K[0] = 0.35; K[1] = 0.25; hy = Math.sin(t * 0.5 + seed) * 0.3;
      arms = [[0.1 + Math.sin(t * 1.1) * 0.05, 0.12, 0.1], [0.12, 0.12, 0.1]]; break;
    case 'inspect':
      lean = 0.95; hp = -0.3; L[0] = L[1] = 0.35; K[0] = K[1] = 0.3; arms = [[1.1, 0.1, 0.4], [1.0, 0.1, 0.4]]; break;
    case 'talk':
      hy = Math.sin(t * 1.5 + seed) * 0.3; arms = [[0.9 + Math.sin(t * 3 + seed) * 0.4, 0.3, 1.2 + Math.sin(t * 2 + seed) * 0.3], [0.7 + Math.sin(t * 2.3 + seed + 1) * 0.4, 0.3, 1.0]]; break;
    case 'holdradio':
      hp = 0.15; arms = [[1.1, 0.0, 1.4], [0.1, 0.12, 0.1]]; break;
    case 'crouch':
      L[0] = L[1] = 1.0; K[0] = K[1] = 1.9; lean = 0.6; hp = -0.3; arms = [[0.6, 0.1, 0.5], [0.6, 0.1, 0.5]]; break;
  }
  const hipY = Math.max(0.5 * Math.cos(L[0]) + 0.5 * Math.cos(L[0] - K[0]), 0.5 * Math.cos(L[1]) + 0.5 * Math.cos(L[1] - K[1])) + 0.1;
  return {L, K, arms, lean, twist, hp, hy, hr, hipY};
}

const Limb: React.FC<{len: number; r: number; m: THREE.Material}> = ({len, r, m}) => (
  <>
    <mesh position={[0, -len / 2, 0]} material={m}><cylinderGeometry args={[r, r * 0.9, len, 10]} /></mesh>
    <mesh material={m}><sphereGeometry args={[r * 1.3, 10, 8]} /></mesh>
  </>
);

export type FigureProps = {
  frame: number; pos: V3; yaw?: number; pose?: Pose3; emotion?: Emotion; color?: string; zombie?: boolean; cps?: number; seed?: number;
  scale?: number; hold?: 'radio' | 'file' | null; look?: number; headYaw?: number; opacity?: number; sil?: boolean; tint?: string; tOffset?: number;
};

export const Figure: React.FC<FigureProps> = ({frame, pos, yaw = 0, pose = 'stand', emotion = 'neutral', color = '#f2f2ee', zombie = false, cps = 0, seed = 0,
  scale = 0.85, hold = null, look = 0, headYaw = 0, opacity = 1, sil = false, tint = '#ffffff', tOffset = 0}) => {
  const t = frame / FPS + tOffset;
  const limbC = sil ? '#050505' : zombie ? '#a8b894' : color;
  const headC = sil ? '#050505' : zombie ? '#9fb08b' : '#f7f3e8';
  const mats = useMemo(() => ({
    limb: new THREE.MeshStandardMaterial({color: limbC, roughness: 0.55}),
    head: new THREE.MeshStandardMaterial({color: headC, roughness: 0.5}),
    dark: new THREE.MeshStandardMaterial({color: '#1b1b1d', roughness: 0.7}),
  }), [limbC, headC]);
  const {canvas, tex} = useMemo(() => {
    const c = document.createElement('canvas'); c.width = 256; c.height = 256;
    const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return {canvas: c, tex: tx};
  }, []);
  useEffect(() => () => tex.dispose(), [tex]);
  if (opacity <= 0.01) return null;
  Object.values(mats).forEach((m) => { m.transparent = opacity < 1; m.opacity = opacity; });
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 256, 256); ctx.save(); ctx.translate(128, 128); ctx.scale(5.2, 5.2);
  if (zombie && !sil) { ctx.fillStyle = 'rgba(40,20,40,0.55)'; [-7.5, 7.5].forEach((x) => { ctx.beginPath(); ctx.ellipse(x, -2, 8, 7, 0, 0, 7); ctx.fill(); }); }
  face(ctx, 0, 0, zombie && emotion !== 'zombie' ? 'zombie' : emotion, t, 0, look, sil, seed);
  ctx.restore(); tex.needsUpdate = true;

  const A = solve(pose, t, cps, seed);
  const sh = (i: number) => A.arms[i];
  return (
    <group position={pos} rotation={[0, yaw, 0]} scale={scale}>
      <group position={[0, A.hipY, 0]}>
        {[0, 1].map((i) => (
          <group key={i} position={[i ? -0.17 : 0.17, 0, 0]} rotation={[-A.L[i], 0, 0]}>
            <Limb len={0.5} r={0.075} m={mats.limb} />
            <group position={[0, -0.5, 0]} rotation={[A.K[i], 0, 0]}>
              <Limb len={0.5} r={0.065} m={mats.limb} />
              <mesh position={[0, -0.52, 0.07]} material={mats.dark}><boxGeometry args={[0.16, 0.09, 0.32]} /></mesh>
            </group>
          </group>
        ))}
        <group rotation={[A.lean, A.twist, 0]}>
          <mesh position={[0, 0.425, 0]} material={mats.limb}><cylinderGeometry args={[0.085, 0.085, 0.85, 10]} /></mesh>
          {[0, 1].map((i) => (
            <group key={i} position={[i ? -0.1 : 0.1, 0.8, 0]} rotation={[-sh(i)[0], 0, i ? -sh(i)[1] : sh(i)[1]]}>
              <Limb len={0.42} r={0.062} m={mats.limb} />
              <group position={[0, -0.42, 0]} rotation={[-sh(i)[2], 0, 0]}>
                <Limb len={0.42} r={0.055} m={mats.limb} />
                <mesh position={[0, -0.44, 0]} material={mats.head}><sphereGeometry args={[0.08, 10, 8]} /></mesh>
                {i === 0 && hold === 'radio' && (
                  <group position={[0, -0.5, 0.12]}>
                    <mesh><boxGeometry args={[0.36, 0.24, 0.14]} /><meshStandardMaterial color="#7a5c3a" roughness={0.8} /></mesh>
                    <mesh position={[0.12, 0.2, 0]} rotation={[0, 0, -0.3]}><cylinderGeometry args={[0.012, 0.012, 0.4, 5]} /><meshStandardMaterial color="#ccc" /></mesh>
                    <mesh position={[-0.05, 0, 0.075]} userData={{ns: true}}><planeGeometry args={[0.18, 0.12]} /><meshBasicMaterial color={Math.sin(t * 6) > 0 ? '#ffb347' : '#8a5a20'} /></mesh>
                  </group>
                )}
              </group>
            </group>
          ))}
          {hold === 'file' && <mesh position={[0, 0.45, 0.32]} rotation={[-0.5, 0, 0]}><boxGeometry args={[0.5, 0.02, 0.38]} /><meshStandardMaterial color="#f1ecd8" /></mesh>}
          <group position={[0, 0.85, 0]} rotation={[A.hp, A.hy + headYaw, A.hr]}>
            <mesh position={[0, 0.4, 0]} material={mats.head}><sphereGeometry args={[0.42, 24, 18]} /></mesh>
            <mesh position={[0, 0.4, 0.405]} userData={{ns: true}}>
              <planeGeometry args={[1.03, 1.03]} />
              <meshBasicMaterial map={tex} transparent opacity={opacity} toneMapped={false} color={tint} depthWrite={false} />
            </mesh>
          </group>
        </group>
      </group>
    </group>
  );
};

// Berjalan menyusuri titik-titik jalur (x,y,z) dengan kecepatan konstan; arah menghadap mengikuti jalur (halus di tikungan).
export const PathFigure: React.FC<Omit<FigureProps, 'pos' | 'yaw' | 'cps'> & {
  path: V3[]; speed: number; startFrame?: number; loop?: boolean; idlePose?: Pose3; endPose?: Pose3; endYaw?: number; hideBefore?: boolean; phase?: number;
}> = ({path, speed, startFrame = 0, loop = false, pose = 'walk', idlePose, endPose, endYaw, hideBefore = false, phase = 0, frame, ...rest}) => {
  const cum = [0];
  for (let i = 1; i < path.length; i++) cum.push(cum[i - 1] + Math.hypot(path[i][0] - path[i - 1][0], path[i][2] - path[i - 1][2]));
  const total = cum[cum.length - 1] || 1;
  const at = (s: number): V3 => {
    const c = Math.min(Math.max(s, 0), total);
    let i = 1; while (i < cum.length - 1 && cum[i] < c) i++;
    const k = (c - cum[i - 1]) / Math.max(1e-6, cum[i] - cum[i - 1]);
    const a = path[i - 1], b = path[i];
    return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
  };
  const started = frame >= startFrame;
  if (!started && hideBefore) return null;
  let s = Math.max(0, (frame - startFrame) / FPS) * speed + phase * total;
  const done = !loop && s >= total;
  s = loop ? s % total : Math.min(s, total);
  const p0 = at(s - 0.6), p1 = at(s + 0.6);
  const yaw = done && endYaw !== undefined ? endYaw : Math.atan2(p1[0] - p0[0], p1[2] - p0[2]) || 0;
  const moving = started && !done;
  const cur = moving ? pose : done ? endPose ?? idlePose ?? 'stand' : idlePose ?? 'stand';
  const cps = moving ? speed / (STRIDE[pose] ?? 2) : 0;
  return <Figure frame={frame} pos={at(s)} yaw={yaw} pose={cur} cps={cps} {...rest} />;
};
