import React, {useLayoutEffect, useMemo} from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {CameraRig, Key} from '../three/CameraRig';
import type {V3} from './figure3d';

const ShadowAll: React.FC = () => {
  const scene = useThree((s) => s.scene);
  useLayoutEffect(() => { scene.traverse((o: any) => { if (o.isMesh && !o.userData?.ns) { o.castShadow = true; o.receiveShadow = true; } }); });
  return null;
};

// Kamera sinematik PERSPEKTIF (skala normal). lights=true untuk ruangan interior; kota (World) membawa cahayanya sendiri.
export const Stage: React.FC<{
  frame: number; keys: Key[]; sky: [string, string]; fog?: [string, number, number]; lights?: boolean; focus?: V3; linear?: boolean;
  amb?: number; hemi?: [string, string]; children: React.ReactNode;
}> = ({frame, keys, sky, fog, lights = false, focus = [0, 0, 0], linear, amb = 0.5, hemi = ['#9fb0c0', '#2a2a28'], children}) => {
  const {width, height} = useVideoConfig();
  const target = useMemo(() => new THREE.Object3D(), []);
  target.position.set(...focus);
  return (
    <AbsoluteFill style={{background: `linear-gradient(${sky[0]}, ${sky[1]})`}}>
      <ThreeCanvas width={width} height={height} shadows camera={{fov: 50, near: 0.1, far: 900, position: [0, 2, 10]}}>
        <CameraRig keys={keys} frame={frame} linear={linear} />
        {fog && <fog attach="fog" args={fog} />}
        {lights && (
          <>
            <hemisphereLight args={[hemi[0], hemi[1], amb]} />
            <primitive object={target} />
            <directionalLight target={target} position={[focus[0] + 3, focus[1] + 8, focus[2] + 5]} intensity={0.5} castShadow shadow-mapSize={[1024, 1024]}
              shadow-camera-left={-12} shadow-camera-right={12} shadow-camera-top={12} shadow-camera-bottom={-12} shadow-camera-near={0.5} shadow-camera-far={40} shadow-bias={-0.0006} />
          </>
        )}
        {children}
        <ShadowAll />
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
