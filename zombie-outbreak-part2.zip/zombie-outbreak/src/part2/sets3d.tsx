import React, {useMemo} from 'react';
import * as THREE from 'three';
import {FONT} from '../fonts';
import {boxGeo, Ambulance} from '../three/world';
import {makeFacade, makeTrainSide, mix, rng, toTex} from '../three/textures';

type V3 = [number, number, number];
const Box: React.FC<{p: V3; s: V3; c: string; rough?: number; metal?: number; rot?: V3; emi?: string; ei?: number}> = ({p, s, c, rough = 0.85, metal = 0.05, rot, emi, ei = 1}) => (
  <mesh position={p} rotation={rot}><boxGeometry args={s} /><meshStandardMaterial color={c} roughness={rough} metalness={metal} emissive={emi ?? '#000'} emissiveIntensity={emi ? ei : 0} /></mesh>
);
const cv = (w: number, h: number) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
function makeSign(lines: string[], w: number, h: number, bg: string, fg: string, size: number, paint = false) {
  const c = cv(w, h), g = c.getContext('2d')!;
  if (bg !== 'none') { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
  g.fillStyle = fg; g.textAlign = 'center'; g.font = `900 ${size}px ${FONT}`;
  lines.forEach((l, i) => g.fillText(l, w / 2, h / 2 + (i - (lines.length - 1) / 2) * size * 1.15 + size * 0.35));
  if (paint) { const r = rng(5); for (let i = 0; i < 26; i++) { const x = 30 + r() * (w - 60); g.fillRect(x, h * 0.55, 4, 20 + r() * 90); } }
  return toTex(c, false);
}
function makeVine(seed: number) {
  const c = cv(256, 512), g = c.getContext('2d')!, r = rng(seed);
  for (let i = 0; i < 14; i++) {
    let x = r() * 256, y = 512; const h = 120 + r() * 380; g.strokeStyle = '#3e5a2a'; g.lineWidth = 2 + r() * 2; g.beginPath(); g.moveTo(x, y);
    const pts: number[][] = [];
    for (let k = 0; k < 12; k++) { x += (r() - 0.5) * 40; y -= h / 12; g.lineTo(x, y); pts.push([x, y]); }
    g.stroke();
    pts.forEach(([px, py]) => { g.fillStyle = `hsl(${90 + r() * 30},40%,${25 + r() * 15}%)`; g.beginPath(); g.ellipse(px + (r() - 0.5) * 14, py, 7, 4, r() * 3, 0, 7); g.fill(); });
  }
  return toTex(c, false);
}
export const flick = (f: number, seed = 0) => (Math.sin(f * 1.9 + seed * 7) > 0.1 ? 1 : 0.25);

/* ================= RUMAH SAKIT (eksterior, di sisi kiri jalan, wajah menghadap +x) ================= */
export const Hospital: React.FC<{frame: number; z: number}> = ({frame, z}) => {
  const A = useMemo(() => {
    const fac = makeFacade(0, 0.9, ['#cfd2c8', '#1b232b']);
    const m = new THREE.MeshStandardMaterial({map: fac, roughness: 0.85});
    return {m, roof: new THREE.MeshStandardMaterial({color: '#555a5c'}), geo: boxGeo(24, 24, 26), sign: makeSign(['RUMAH SAKIT'], 512, 96, '#1d5fa8', '#ffffff', 64), vine: makeVine(3)};
  }, []);
  const X = -29, FX = -17; // sisi depan gedung di x=-17
  const gateOpen = 0.9;
  return (
    <group>
      <mesh position={[X, 12, z]} geometry={A.geo} material={[A.m, A.m, A.roof, A.roof, A.m, A.m]} />
      <mesh position={[FX + 0.04, 1.7, z]} rotation={[0, Math.PI / 2, 0]}><planeGeometry args={[6, 3.4]} /><meshStandardMaterial color="#0d1418" roughness={0.1} metalness={0.5} /></mesh>
      <Box p={[FX + 2.2, 3.7, z]} s={[4.4, 0.3, 8]} c="#b8bbb2" />
      {[-3.6, 3.6].map((d) => <Box key={d} p={[FX + 3.9, 1.85, z + d]} s={[0.3, 3.7, 0.3]} c="#9a9d94" />)}
      <Box p={[FX + 0.2, 17, z]} s={[0.4, 6, 1.8]} c="#c4231a" emi="#ff2a1a" ei={0.5 * flick(frame, 1)} />
      <Box p={[FX + 0.2, 17, z]} s={[0.4, 1.8, 6]} c="#c4231a" emi="#ff2a1a" ei={0.5 * flick(frame, 1)} />
      <mesh position={[FX + 0.06, 21, z]} rotation={[0, Math.PI / 2, 0]} userData={{ns: true}}><planeGeometry args={[10, 1.9]} /><meshBasicMaterial map={A.sign} toneMapped={false} /></mesh>
      <mesh position={[FX + 0.07, 7, z - 8]} rotation={[0, Math.PI / 2, 0]} userData={{ns: true}}><planeGeometry args={[7, 14]} /><meshBasicMaterial map={A.vine} transparent alphaTest={0.3} /></mesh>
      <mesh position={[FX + 0.07, 5, z + 9]} rotation={[0, Math.PI / 2, 0]} userData={{ns: true}}><planeGeometry args={[5, 10]} /><meshBasicMaterial map={A.vine} transparent alphaTest={0.3} /></mesh>
      <mesh rotation-x={-Math.PI / 2} position={[-14, 0.03, z]}><planeGeometry args={[6, 26]} /><meshStandardMaterial color="#6f6f68" roughness={0.95} /></mesh>
      {/* pagar + gerbang terbuka */}
      {Array.from({length: 22}, (_, i) => { const zz = z - 12.6 + i * 1.2; return Math.abs(zz - z) < 2.2 ? null : <Box key={i} p={[-11.3, 0.8, zz]} s={[0.08, 1.6, 0.08]} c="#3a3d3f" />; })}
      <Box p={[-11.3, 1.4, z - 7.5]} s={[0.06, 0.06, 10]} c="#3a3d3f" /><Box p={[-11.3, 1.4, z + 7.5]} s={[0.06, 0.06, 10]} c="#3a3d3f" />
      <Box p={[-11.9, 0.8, z - 2.3 - gateOpen]} s={[0.06, 1.6, 2.0]} c="#4a4d4f" rot={[0, 0.9, 0]} />
      <Ambulance frame={frame} pos={[-14.5, 0, z + 9]} ry={0.4} />
      {/* brankar terguling + semak liar */}
      <Box p={[-13, 0.35, z - 4]} s={[2, 0.1, 0.7]} c="#9aa0a4" rot={[0.1, 0.6, 1.3]} />
      {[[-12.6, z + 6], [-15, z - 9], [-12, z - 11], [-16, z + 11]].map(([x, zz], i) => <mesh key={i} position={[x, 0.5, zz]} scale={[1.4, 0.9, 1.4]}><icosahedronGeometry args={[0.8, 0]} /><meshStandardMaterial color="#4c6636" roughness={1} /></mesh>)}
    </group>
  );
};

/* ================= KRL (melintang jalan; terbengkalai, ditumbuhi tanaman) ================= */
const KrlCar: React.FC<{cx: number; z: number; tex: THREE.Texture; pantograph?: boolean; cab?: boolean}> = ({cx, z, tex, pantograph, cab}) => (
  <group position={[cx, 0, z]}>
    <Box p={[0, 1.9, 0]} s={[13, 3.2, 3]} c="#b7bcc0" rough={0.5} metal={0.35} />
    <mesh position={[0, 1.95, 1.51]}><planeGeometry args={[13, 3.3]} /><meshStandardMaterial map={tex} roughness={0.45} metalness={0.3} /></mesh>
    <mesh position={[0, 1.95, -1.51]} rotation={[0, Math.PI, 0]}><planeGeometry args={[13, 3.3]} /><meshStandardMaterial map={tex} roughness={0.45} metalness={0.3} /></mesh>
    <Box p={[0, 3.75, 0]} s={[12.6, 0.25, 2.6]} c="#8f959a" />
    {[-3.2, 3.2].map((x) => <Box key={x} p={[x, 4.05, 0]} s={[2.2, 0.5, 1.6]} c="#a6abb0" />)}
    <Box p={[0, 0.65, 0]} s={[11, 0.7, 2.4]} c="#202328" />
    {[-4.2, 4.2].flatMap((x) => [-1, 1].map((s) => <mesh key={`${x}${s}`} position={[x + s * 0.0, 0.45, s * 1.0]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.45, 0.45, 0.14, 16]} /><meshStandardMaterial color="#17181a" metalness={0.6} roughness={0.4} /></mesh>))}
    {pantograph && <><Box p={[0, 4.6, 0]} s={[0.08, 1.2, 0.08]} c="#333" rot={[0, 0, 0.5]} /><Box p={[0.5, 5.2, 0]} s={[0.12, 0.1, 2]} c="#222" /></>}
    {cab && <><Box p={[6.52, 2.2, 0]} s={[0.05, 1.2, 2.4]} c="#0b1014" rough={0.1} metal={0.6} /><Box p={[6.52, 1.0, 0.9]} s={[0.05, 0.25, 0.4]} c="#fff6d8" emi="#fff6d8" ei={0.2} /></>}
    {[[-3, 0.8], [2, -0.9], [4.5, 0.9]].map(([x, s], i) => <mesh key={i} position={[x, 0.7, s > 0 ? 1.55 : -1.55]} scale={[1.2, 0.8, 0.5]}><icosahedronGeometry args={[0.7, 0]} /><meshStandardMaterial color="#506a38" roughness={1} /></mesh>)}
  </group>
);
export const KrlTrain: React.FC<{z: number}> = ({z}) => {
  const tex = useMemo(() => makeTrainSide(), []);
  return (
    <group>
      <KrlCar cx={0} z={z} tex={tex} />
      <KrlCar cx={13.3} z={z} tex={tex} pantograph cab />
      <Box p={[6.65, 0.9, z]} s={[0.4, 0.3, 0.5]} c="#222" />
      <Box p={[6.65, 0.1, z]} s={[60, 0.08, 0.16]} c="#3a3a3a" metal={0.6} /> 
      <Box p={[6.65, 0.06, z + 0.75]} s={[60, 0.14, 0.14]} c="#6b5a4a" metal={0.6} rough={0.5} />
      <Box p={[6.65, 0.06, z - 0.75]} s={[60, 0.14, 0.14]} c="#6b5a4a" metal={0.6} rough={0.5} />
      {Array.from({length: 70}, (_, i) => <Box key={i} p={[-23 + i * 0.7, 0.03, z]} s={[0.3, 0.08, 2.6]} c="#4a3f35" />)}
      {[-1, 1].map((s) => <Box key={s} p={[-8, 1.0, z + s * 6]} s={[0.1, 2, 0.1]} c="#e6e6e0" />)}
    </group>
  );
};

/* ================= RUANGAN INTERIOR (skala normal; sisi depan terbuka untuk kamera) ================= */
const Room: React.FC<{w: number; d: number; h: number; wall: string; floor: string; rough?: number; children?: React.ReactNode}> = ({w, d, h, wall, floor, rough = 0.3, children}) => (
  <group>
    <mesh rotation-x={-Math.PI / 2} position={[0, 0, -d / 2]}><planeGeometry args={[w, d]} /><meshStandardMaterial color={floor} roughness={rough} metalness={0.15} /></mesh>
    <Box p={[0, h / 2, -d - 0.1]} s={[w + 0.4, h, 0.2]} c={wall} />
    <Box p={[-w / 2 - 0.1, h / 2, -d / 2]} s={[0.2, h, d]} c={wall} />
    <Box p={[w / 2 + 0.1, h / 2, -d / 2]} s={[0.2, h, d]} c={wall} />
    <Box p={[0, h + 0.1, -d / 2]} s={[w + 0.4, 0.2, d]} c={mix(wall, '#000000', 0.25)} />
    <Box p={[0, 0.1, -d + 0.02]} s={[w, 0.2, 0.06]} c="#2b2d2e" />
    {children}
  </group>
);
const Lamp: React.FC<{p: V3; f: number; seed: number; col?: string; inten?: number; steady?: boolean}> = ({p, f, seed, col = '#dfeaff', inten = 6, steady}) => {
  const k = steady ? 1 : flick(f, seed);
  return (<group position={p}><Box p={[0, 0, 0]} s={[1.2, 0.08, 0.3]} c={mix('#1a1c1e', col, k)} emi={col} ei={k} /><pointLight intensity={inten * k} distance={11} color={col} /></group>);
};

export const Lobby: React.FC<{frame: number}> = ({frame}) => {
  const A = useMemo(() => {
    const r = rng(8);
    return {text: makeSign(['JANGAN TURUN', 'KE LANTAI BAWAH'], 1024, 320, 'none', '#b3140f', 100, true), papers: Array.from({length: 34}, () => ({p: [(r() - 0.5) * 9, 0.03, -0.5 - r() * 7.5] as V3, ry: r() * 3, c: r() < 0.2 ? '#e8d9a8' : '#f1f1ec'})),
      cross: makeSign(['+'], 128, 128, '#1d5fa8', '#ffffff', 120)};
  }, []);
  return (
    <Room w={11} d={9} h={3.6} wall="#c9ccc2" floor="#8a8c84">
      <mesh position={[-1.3, 2.0, -8.88]} userData={{ns: true}}><planeGeometry args={[6, 1.9]} /><meshBasicMaterial map={A.text} transparent toneMapped={false} /></mesh>
      <Box p={[3.9, 1.3, -8.85]} s={[1.7, 2.6, 0.1]} c="#050607" />
      <Box p={[3.9, 2.9, -8.8]} s={[1.4, 0.3, 0.05]} c="#5a0a08" emi="#ff2a1a" ei={0.6 * flick(frame, 2)} />
      <Box p={[3.6, 0.55, -5.5]} s={[3.8, 1.1, 0.9]} c="#6a5a48" /><Box p={[3.6, 1.12, -5.5]} s={[3.9, 0.06, 1.0]} c="#8a7a64" />
      <Box p={[4.2, 1.5, -5.6]} s={[0.7, 0.45, 0.06]} c="#0b0e10" emi="#2a4a5a" ei={0.4} rot={[0, -0.3, 0]} />
      {[-4.4, -2.4].map((x, i) => <Box key={i} p={[x, 0.3, -8.4]} s={[1.6, 0.5, 0.6]} c="#3d5f7a" rot={[0, 0, i ? 0.35 : 0]} />)}
      <Box p={[-1.3, 0.5, -4.2]} s={[2.0, 0.12, 0.75]} c="#a4a9ad" rot={[0.15, 0.5, 1.15]} metal={0.4} />
      <Box p={[-1.0, 0.62, -4.2]} s={[1.8, 0.14, 0.65]} c="#f0f0ec" rot={[0.15, 0.5, 1.15]} />
      {A.papers.map((q, i) => <Box key={i} p={q.p} s={[0.45, 0.01, 0.32]} c={q.c} rot={[0, q.ry, 0]} />)}
      <Lamp p={[-2.5, 3.5, -3]} f={frame} seed={1} /><Lamp p={[2.5, 3.5, -6]} f={frame} seed={3} />
      <pointLight position={[3.9, 2.5, -8]} intensity={4 * flick(frame, 2)} distance={8} color="#ff2a1a" />
    </Room>
  );
};

export const Archive: React.FC<{frame: number}> = ({frame}) => {
  const A = useMemo(() => {
    const r = rng(21), cols = ['#a33', '#37a', '#3a6', '#cb3', '#c73', '#ddd', '#76a'];
    const shelf = () => Array.from({length: 5 * 14}, (_, i) => ({x: (i % 14) * 0.19 - 1.25, y: 0.3 + Math.floor(i / 14) * 0.48, c: cols[(r() * 7) | 0], h: 0.3 + r() * 0.14}));
    return {sh: [shelf(), shelf(), shelf()], card: makeSign(['PASIEN 01', 'PETUGAS KEBERSIHAN', 'SAKIT: 3 HARI SEBELUM WABAH', 'HASIL LAB: TIDAK DIKENALI'], 768, 512, '#efe9d2', '#2a2a2a', 44)};
  }, []);
  const Shelf = ({p, ry, k}: {p: V3; ry: number; k: number}) => (
    <group position={p} rotation={[0, ry, 0]}>
      <Box p={[0, 1.2, 0]} s={[2.8, 2.4, 0.5]} c="#4b4f52" />
      {A.sh[k].map((b, i) => <mesh key={i} position={[b.x, b.y, 0.28]}><boxGeometry args={[0.15, b.h, 0.3]} /><meshStandardMaterial color={b.c} roughness={0.8} /></mesh>)}
    </group>
  );
  return (
    <Room w={9} d={7} h={3.2} wall="#bfc2b6" floor="#7d7f78">
      <Shelf p={[-2.9, 0, -6.6]} ry={0} k={0} /><Shelf p={[2.9, 0, -6.6]} ry={0} k={1} /><Shelf p={[-4.1, 0, -3.5]} ry={Math.PI / 2} k={2} />
      <mesh position={[0, 1.9, -6.88]} userData={{ns: true}}><planeGeometry args={[2.2, 1.45]} /><meshBasicMaterial map={A.card} toneMapped={false} /></mesh>
      <Box p={[0, 0.4, -5.2]} s={[2.4, 0.8, 1.0]} c="#6e5a44" /><Box p={[0, 0.82, -5.2]} s={[2.5, 0.06, 1.1]} c="#8a7458" />
      <Box p={[1.6, 0.2, -2.5]} s={[0.8, 0.4, 0.6]} c="#a68c64" /><Box p={[1.6, 0.6, -2.5]} s={[0.7, 0.4, 0.5]} c="#9c825a" rot={[0, 0.3, 0]} />
      <group position={[-0.8, 0.85, -5.2]}><Box p={[0, 0.2, 0]} s={[0.08, 0.4, 0.08]} c="#222" /><mesh position={[0, 0.45, 0]}><sphereGeometry args={[0.16, 12, 8]} /><meshBasicMaterial color="#ffd48a" /></mesh><pointLight position={[0, 0.5, 0.2]} intensity={5 * (0.85 + 0.15 * Math.sin(frame / 5))} distance={7} color="#ffcf8a" /></group>
      <Lamp p={[0, 3.1, -3]} f={frame} seed={4} steady inten={3} />
    </Room>
  );
};

export const Corridor: React.FC<{frame: number}> = ({frame}) => (
  <Room w={3.4} d={38} h={3.2} wall="#b9bdb2" floor="#6d716b" rough={0.2}>
    {Array.from({length: 8}, (_, i) => [-1, 1].map((s) => (
      <group key={`${i}${s}`} position={[s * 1.68, 0, -3 - i * 4.4]}>
        <Box p={[0, 1.1, 0]} s={[0.08, 2.2, 1.1]} c="#5a4636" /><Box p={[-s * 0.05, 1.6, 0]} s={[0.02, 0.5, 0.4]} c="#0b1013" emi="#1a2a30" ei={0.4} />
      </group>
    )))}
    {Array.from({length: 7}, (_, i) => <Lamp key={i} p={[0, 3.12, -3 - i * 5.2]} f={frame} seed={i + 1} inten={4} steady={i === 0} />)}
    <Box p={[1.0, 0.45, -9]} s={[0.7, 0.1, 1.9]} c="#9aa0a4" /><Box p={[1.0, 0.6, -9]} s={[0.6, 0.12, 1.7]} c="#ecece8" />
    <Box p={[-0.6, 2.8, -37.5]} s={[0.9, 0.3, 0.05]} c="#0a3a1a" emi="#27ff6a" ei={0.9} />
  </Room>
);

export const Pharmacy: React.FC<{frame: number; box?: number}> = ({frame, box = 1}) => {
  const A = useMemo(() => {
    const r = rng(33), cols = ['#a33', '#37a', '#3a6', '#cb3', '#eee', '#c73'];
    return {bottles: Array.from({length: 2 * 4 * 12}, (_, i) => ({u: Math.floor(i / 48), x: (i % 12) * 0.26 - 1.4, y: 0.62 + Math.floor((i % 48) / 12) * 0.5, c: cols[(r() * 6) | 0], h: 0.18 + r() * 0.1})),
      note: makeSign(['HANYA CUKUP', 'UNTUK SATU ORANG'], 512, 256, '#efe9d2', '#8a0f0a', 50)};
  }, []);
  const pulse = 0.7 + 0.3 * Math.sin(frame / 6);
  return (
    <Room w={7.5} d={6} h={3.2} wall="#c4c8be" floor="#7a8f86">
      {[-1.9, 1.9].map((x, u) => (
        <group key={x} position={[x, 0, -5.7]}>
          <Box p={[0, 1.2, 0]} s={[3.5, 2.4, 0.5]} c="#4e5356" />
          {A.bottles.filter((b) => b.u === u).map((b, i) => <mesh key={i} position={[b.x, b.y, 0.28]}><cylinderGeometry args={[0.06, 0.06, b.h, 8]} /><meshStandardMaterial color={b.c} roughness={0.4} /></mesh>)}
        </group>
      ))}
      <Box p={[1.4, 0.3, -5.45]} s={[0.55, 0.32, 0.4]} c="#8a0f0a" emi="#ff2a1a" ei={0.8 * box * pulse} />
      <pointLight position={[1.4, 0.7, -5.0]} intensity={3 * box * pulse} distance={5} color="#ff2a1a" />
      <mesh position={[0.85, 0.2, -5.3]} rotation={[-1.2, 0, 0]} userData={{ns: true}}><planeGeometry args={[0.5, 0.25]} /><meshBasicMaterial map={A.note} toneMapped={false} /></mesh>
      <Box p={[-3.0, 0.5, -2]} s={[1.0, 1.0, 3.6]} c="#8d8f8a" />
      <Box p={[3.35, 1.0, -2.2]} s={[0.7, 2.0, 0.9]} c="#e6e8e6" /><Box p={[3.0, 1.5, -2.2]} s={[0.02, 0.2, 0.5]} c="#7ad0ff" emi="#7ad0ff" ei={0.8} />
      <Box p={[-3.7, 1.1, -3.4]} s={[0.12, 2.2, 1.1]} c="#5a4636" /><Box p={[-3.62, 1.9, -3.4]} s={[0.04, 0.12, 0.12]} c="#ff2a1a" emi="#ff2a1a" ei={1} />
      <Box p={[-2.4, 1.1, -5.95]} s={[1.3, 2.3, 0.05]} c="#05080a" />
      <Lamp p={[0, 3.1, -2.5]} f={frame} seed={6} steady inten={4} />
    </Room>
  );
};
