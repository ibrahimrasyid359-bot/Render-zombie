import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {FPS} from '../config';
import {DURATION2} from './config2';
import {L2, SCENES2, TL2} from './script2';
import {FontGate, Subtitles} from '../ui';
import {SceneArsip, SceneGerbang, SceneJalan, SceneLobi, SceneLorong, SceneObat, ScenePilihan, SceneRadio} from './scenes2';

const OVERLAP = 12;
const MAP: Record<string, React.FC<{from: number; dur: number}>> = {
  jalan: SceneJalan, gerbang: SceneGerbang, lobi: SceneLobi, arsip: SceneArsip, lorong: SceneLorong, obat: SceneObat, radio: SceneRadio, pilihan: ScenePilihan,
};
const Fade: React.FC<{children: React.ReactNode; on: boolean}> = ({children, on}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: on ? interpolate(f, [0, OVERLAP], [0, 1], {extrapolateRight: 'clamp'}) : 1}}>{children}</AbsoluteFill>;
};
const sfx = (file: string, frame: number, vol: number, dur = 120) => (
  <Sequence key={`${file}${frame}`} from={Math.max(0, Math.round(frame))} durationInFrames={dur}>
    <Audio src={staticFile(`sfx/${file}`)} volume={vol} />
  </Sequence>
);

export const Part2: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    <Audio src={staticFile('part2/voiceover2.mp3')} volume={1} />
    <Audio src={staticFile('sfx/music.mp3')} loop volume={(f) => interpolate(f, [0, 60, DURATION2 - 90, DURATION2], [0, 0.12, 0.12, 0])} />
    <Audio src={staticFile('sfx/wind.mp3')} loop volume={0.1} />
    {sfx('groan.mp3', L2(1) + 3 * FPS, 0.3, 90)}
    {sfx('hit.mp3', L2(2), 0.5)}
    {sfx('groan.mp3', L2(6) + 1.2 * FPS, 0.45, 90)}
    {sfx('groan.mp3', L2(6) + 3.5 * FPS, 0.4, 90)}
    {sfx('hit.mp3', L2(9), 0.6)}
    {sfx('static.mp3', L2(10), 0.3, 6 * FPS)}
    {sfx('groan.mp3', L2(10) + 1.5 * FPS, 0.45, 90)}
    {sfx('pop.mp3', L2(12), 0.6, 20)}
    {sfx('pop.mp3', L2(13), 0.6, 20)}
    {sfx('pop.mp3', L2(14), 0.6, 20)}
    <FontGate>
      {SCENES2.map((s, i) => {
        const from = i === 0 ? 0 : s.start - OVERLAP;
        const C = MAP[s.id];
        return (
          <Sequence key={s.id} from={from} durationInFrames={s.end - from}>
            <Fade on={i > 0}><C from={from} dur={s.end - from} /></Fade>
          </Sequence>
        );
      })}
      <Subtitles chunks={TL2.chunks} />
    </FontGate>
  </AbsoluteFill>
);
