import {FPS} from '../config';
import timing from './timing2.json';
export const AUDIO2_SECONDS = timing.audioSeconds; // durasi voiceover2.mp3
export const DURATION2 = Math.ceil(AUDIO2_SECONDS * FPS) + 15;
