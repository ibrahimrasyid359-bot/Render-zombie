import {FPS} from './config';

export type Word = {text: string; start: number; end: number; line: number};
export type Chunk = {words: Word[]; start: number; end: number};
export type LineIn = {text: string; tag?: string};

export function buildTimeline(lines: LineIn[], audioSeconds: number, captions: any[], presetStarts?: number[], textFromCaptions = false) {
  const sw = lines.flatMap((l, line) => l.text.split(/\s+/).filter(Boolean).map((text) => ({text, line})));
  let words: Word[] = [];
  let lineStart: number[] = [];

  if (captions.length > 20) {
    // timing dari Whisper
    const W: {text: string; start: number; end: number}[] = [];
    for (const c of captions) {
      const t: string = c.text ?? '';
      if (!t.trim() || /^\[.*\]$/.test(t.trim())) continue;
      if (W.length === 0 || /^\s/.test(t)) W.push({text: t.trim(), start: c.startMs / 1000, end: c.endMs / 1000});
      else { W[W.length - 1].text += t; W[W.length - 1].end = c.endMs / 1000; }
    }
    const Ns = sw.length, Nw = W.length;
    const idx = (k: number) => Math.min(Nw - 1, Math.round((k * Nw) / Ns));
    const lineOf = (k: number) => sw[Math.min(Ns - 1, Math.round((k * Ns) / Nw))].line;
    if (textFromCaptions) {
      words = W.map((w, k) => ({text: w.text, start: w.start, end: w.end, line: lineOf(k)}));
    } else {
      words = sw.map((x, k) => ({text: x.text, line: x.line, start: W[idx(k)].start, end: k + 1 < Ns ? W[idx(k + 1)].start : W[Nw - 1].end}));
    }
    lineStart = lines.map((_, i) => words.find((w) => w.line === i)?.start ?? 0);
  } else {
    const weight = (l: LineIn) => {
      let w = l.text.length + 10 * (l.text.match(/\.\.\./g) || []).length + 4 * (l.text.match(/[.?!]/g) || []).length + 3 * (l.text.match(/,/g) || []).length + 6;
      if (/pause/.test(l.tag ?? '')) w += 18;
      return w;
    };
    const tot = lines.reduce((s, l) => s + weight(l), 0);
    const lead = 0.25, span = audioSeconds - lead - 0.5;
    let acc = 0;
    lineStart = lines.map((l) => { const s = lead + (acc / tot) * span; acc += weight(l); return s; });
    if (presetStarts && presetStarts.length === lines.length) lineStart = presetStarts;
    lines.forEach((l, i) => {
      const ws = sw.filter((x) => x.line === i);
      const wts = ws.map((x) => x.text.length + (/\.\.\.$/.test(x.text) ? 8 : /[.,?!]$/.test(x.text) ? 4 : 0));
      const sum = wts.reduce((a, b) => a + b, 0);
      const end = i + 1 < lines.length ? lineStart[i + 1] - 0.25 : audioSeconds - 0.3;
      let t = lineStart[i];
      ws.forEach((x, k) => { const d = ((end - lineStart[i]) * wts[k]) / sum; words.push({text: x.text, start: t, end: t + d, line: i}); t += d; });
    });
  }

  const chunks: Chunk[] = [];
  let cur: Word[] = [];
  const flush = () => { if (cur.length) chunks.push({words: cur, start: cur[0].start, end: cur[cur.length - 1].end}); cur = []; };
  words.forEach((w, i) => {
    cur.push(w);
    const last = words[i + 1]?.line !== w.line;
    if (last || cur.length >= 4 || /[.?!]$|\.\.\.$/.test(w.text) || (cur.length >= 3 && /,$/.test(w.text))) flush();
  });
  flush();
  return {words, lineStart, chunks, lineFrame: (i: number) => Math.round(lineStart[i] * FPS)};
}
