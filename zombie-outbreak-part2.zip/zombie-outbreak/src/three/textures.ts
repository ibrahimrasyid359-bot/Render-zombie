import * as THREE from 'three';

export const rng = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};
export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const mix = (a: string, b: string, t: number) => '#' + new THREE.Color(a).lerp(new THREE.Color(b), clamp01(t)).getHexString();
const cv = (w: number, h: number) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
export const toTex = (c: HTMLCanvasElement, repeat = true) => {
  const t = new THREE.CanvasTexture(c);
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
};

const PAL = [['#575c61', '#1c232b'], ['#6a5d50', '#241f1b'], ['#55605a', '#1b2420'], ['#46586b', '#16222e']];
// tile 512px = 8x8 jendela (16m x 24m)
export function makeFacade(v: number, damage: number, pal?: string[]) {
  const c = cv(512, 512), g = c.getContext('2d')!, r = rng(900 + v * 31 + Math.round(damage * 10));
  const [wall, glass] = pal ?? PAL[v % 4];
  g.fillStyle = wall; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 320; i++) { g.fillStyle = `rgba(0,0,0,${0.03 + r() * 0.1})`; g.fillRect(r() * 512, r() * 512, 2 + r() * 10, 12 + r() * 130); }
  for (let i = 0; i < 90; i++) { g.fillStyle = `rgba(255,255,255,${0.02 + r() * 0.04})`; g.fillRect(r() * 512, r() * 512, 2 + r() * 8, 8 + r() * 60); }
  for (let row = 0; row < 8; row++) {
    g.fillStyle = 'rgba(0,0,0,0.28)'; g.fillRect(0, row * 64 + 57, 512, 5);
    for (let col = 0; col < 8; col++) {
      const x = col * 64 + 12, y = row * 64 + 9;
      g.fillStyle = '#0a0c0e'; g.fillRect(x - 3, y - 3, 46, 52);
      const gr = g.createLinearGradient(x, y, x + 40, y + 46);
      gr.addColorStop(0, glass); gr.addColorStop(0.5, '#33414d'); gr.addColorStop(1, glass);
      g.fillStyle = gr; g.fillRect(x, y, 40, 46);
      if (r() < damage * 0.35) {
        g.fillStyle = '#050607'; g.beginPath(); g.moveTo(x + 8, y); g.lineTo(x + 40, y + 6); g.lineTo(x + 26, y + 30); g.lineTo(x + 40, y + 46); g.lineTo(x, y + 46); g.lineTo(x + 12, y + 22); g.closePath(); g.fill();
      }
      if (r() < 0.15) { g.fillStyle = '#9a9a94'; g.fillRect(x + 4, y + 34, 26, 10); }
    }
  }
  return toTex(c);
}
export function makeLit(v: number) {
  const c = cv(512, 512), g = c.getContext('2d')!, r = rng(5000 + v * 13);
  g.fillStyle = '#000'; g.fillRect(0, 0, 512, 512);
  const cols = ['#ffd48a', '#ffe9b8', '#cfe6ff', '#ffb870', '#ffe0a0'];
  for (let row = 0; row < 8; row++) for (let col = 0; col < 8; col++) {
    if (r() < 0.4) {
      const x = col * 64 + 12, y = row * 64 + 9;
      g.fillStyle = cols[(r() * cols.length) | 0]; g.fillRect(x, y, 40, 46);
      if (r() < 0.4) { g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(x, y, 40, r() * 20 + 8); }
    }
  }
  return toTex(c);
}
export function makeRoad(stains: number) {
  const c = cv(256, 512), g = c.getContext('2d')!, r = rng(77);
  g.fillStyle = '#2d2f33'; g.fillRect(0, 0, 256, 512);
  for (let i = 0; i < 3000; i++) { g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.18)'; g.fillRect(r() * 256, r() * 512, 1 + r() * 3, 1 + r() * 3); }
  for (let i = 0; i < 14; i++) { g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(r() * 200, r() * 480, 30 + r() * 80, 20 + r() * 60); }
  g.fillStyle = '#cfcfc4'; g.fillRect(6, 0, 4, 512); g.fillRect(246, 0, 4, 512);
  for (let y = 0; y < 512; y += 128) g.fillRect(126, y, 4, 64);
  g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.2;
  for (let i = 0; i < 10 + stains * 30; i++) { let x = r() * 256, y = r() * 512; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 6; k++) { x += (r() - 0.5) * 30; y += r() * 26; g.lineTo(x, y); } g.stroke(); }
  for (let i = 0; i < stains * 14; i++) { g.fillStyle = 'rgba(10,10,10,.35)'; g.beginPath(); g.ellipse(r() * 256, r() * 512, 6 + r() * 20, 4 + r() * 14, r() * 3, 0, 7); g.fill(); }
  return toTex(c);
}
export function makeSidewalk() {
  const c = cv(128, 128), g = c.getContext('2d')!, r = rng(5);
  g.fillStyle = '#77776f'; g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 400; i++) { g.fillStyle = `rgba(0,0,0,${r() * 0.12})`; g.fillRect(r() * 128, r() * 128, 2, 2); }
  g.fillStyle = '#55554e'; for (let i = 0; i < 128; i += 32) { g.fillRect(i, 0, 2, 128); g.fillRect(0, i, 128, 2); }
  return toTex(c);
}
export function makeShop(v: number) {
  const c = cv(512, 256), g = c.getContext('2d')!, l = cv(512, 256), gl = l.getContext('2d')!, r = rng(300 + v);
  g.fillStyle = '#2a2b2e'; g.fillRect(0, 0, 512, 256); gl.fillStyle = '#000'; gl.fillRect(0, 0, 512, 256);
  const col = ['#b53a2e', '#2f7d3a', '#2b5fa8', '#d19a1e'][v % 4];
  g.fillStyle = col; g.fillRect(16, 12, 480, 52); gl.fillStyle = col; gl.fillRect(16, 12, 480, 52);
  for (let i = 0; i < 6; i++) { const w = 50 + r() * 12; [g, gl].forEach((q) => { q.fillStyle = 'rgba(255,255,255,.9)'; q.fillRect(30 + i * 70, 28, w, 18); }); }
  if (v % 3 === 1) {
    g.fillStyle = '#74777a'; g.fillRect(16, 76, 480, 170);
    for (let y = 80; y < 246; y += 8) { g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(16, y, 480, 2); }
    g.fillStyle = '#c94'; g.fillRect(60 + r() * 200, 120, 90, 18);
  } else {
    g.fillStyle = '#10161b'; g.fillRect(16, 76, 230, 170); g.fillRect(266, 76, 230, 170);
    gl.fillStyle = 'rgba(255,230,176,.55)'; gl.fillRect(16, 76, 230, 170); gl.fillRect(266, 76, 230, 170);
    g.strokeStyle = '#444'; for (let y = 110; y < 246; y += 44) { g.beginPath(); g.moveTo(20, y); g.lineTo(240, y); g.moveTo(270, y); g.lineTo(490, y); g.stroke(); }
  }
  for (let i = 0; i < 60; i++) { g.fillStyle = 'rgba(0,0,0,.2)'; g.fillRect(r() * 512, r() * 256, 3, 30 + r() * 60); }
  return {map: toTex(c, false), lit: toTex(l, false)};
}
export function makeGlow() {
  const c = cv(128, 128), g = c.getContext('2d')!;
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  return toTex(c, false);
}
export function makeLed(font: string) {
  const c = cv(512, 256), g = c.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 512, 256); gr.addColorStop(0, '#0b5cff'); gr.addColorStop(1, '#ff2a6d');
  g.fillStyle = gr; g.fillRect(0, 0, 512, 256);
  g.fillStyle = '#fff'; g.font = `900 54px ${font}`; g.textAlign = 'center'; g.fillText('KOTA TIDAK', 256, 110); g.fillText('PERNAH TIDUR', 256, 175);
  return toTex(c, false);
}
export function makeChecker() {
  const c = cv(128, 128), g = c.getContext('2d')!;
  g.fillStyle = '#bdbbb0'; g.fillRect(0, 0, 128, 128); g.fillStyle = '#8e8c83'; g.fillRect(0, 0, 64, 64); g.fillRect(64, 64, 64, 64);
  return toTex(c);
}
// 1 gerbong = 13m (1024px). Pintu di u=0.25 dan 0.75.
export function makeTrainSide() {
  const c = cv(1024, 256), g = c.getContext('2d')!;
  g.fillStyle = '#aeb2b5'; g.fillRect(0, 0, 1024, 256);
  g.fillStyle = '#3d4a5c'; g.fillRect(0, 200, 1024, 56);
  g.fillStyle = '#c23b2e'; g.fillRect(0, 150, 1024, 26);
  for (let i = 0; i < 200; i++) { g.fillStyle = 'rgba(0,0,0,.05)'; g.fillRect(Math.random() * 1024, 0, 2, 256); }
  const win = (x: number, w: number) => { g.fillStyle = '#0e1216'; g.fillRect(x, 40, w, 84); g.fillStyle = 'rgba(120,150,170,.18)'; g.fillRect(x + 6, 46, w * 0.4, 70); };
  [[20, 150], [336, 150], [520, 150], [850, 150]].forEach(([x, w]) => win(x, w));
  [256, 768].forEach((cx) => {
    g.fillStyle = '#d7d9da'; g.fillRect(cx - 70, 24, 140, 190);
    const gr = g.createLinearGradient(0, 30, 0, 214); gr.addColorStop(0, '#020303'); gr.addColorStop(1, '#161b1e');
    g.fillStyle = gr; g.fillRect(cx - 62, 30, 124, 184);
  });
  g.fillStyle = '#1e2226'; g.fillRect(0, 0, 14, 256); g.fillRect(1010, 0, 14, 256);
  return toTex(c);
}
export function drawMap(c: HTMLCanvasElement, hi: 'none' | 'A' | 'B', t: number, font: string) {
  const g = c.getContext('2d')!, W = c.width, H = c.height;
  g.fillStyle = '#d8cfb4'; g.fillRect(0, 0, W, H);
  g.strokeStyle = '#f2edd8'; g.lineWidth = 26;
  for (let i = 1; i < 5; i++) { g.beginPath(); g.moveTo(i * W / 5, 0); g.lineTo(i * W / 5, H); g.stroke(); g.beginPath(); g.moveTo(0, i * H / 6); g.lineTo(W, i * H / 6); g.stroke(); }
  g.strokeStyle = '#7f9aa6'; g.lineWidth = 50; g.beginPath(); g.moveTo(0, H * 0.7); g.bezierCurveTo(W * 0.3, H * 0.55, W * 0.6, H * 0.85, W, H * 0.62); g.stroke();
  g.fillStyle = '#9fb48a'; g.fillRect(70, 90, 180, 140); g.fillRect(W - 280, H - 360, 200, 150);
  // pusat kota
  g.fillStyle = 'rgba(190,40,30,.22)'; g.beginPath(); g.arc(W * 0.4, H * 0.38, 190, 0, 7); g.fill();
  g.fillStyle = '#7a1d17'; g.font = `900 46px ${font}`; g.textAlign = 'center'; g.fillText('PUSAT KOTA', W * 0.4, H * 0.38 + 150);
  // titik kamu
  g.fillStyle = '#222'; g.beginPath(); g.arc(W * 0.52, H * 0.66, 16, 0, 7); g.fill();
  g.font = `800 34px ${font}`; g.fillText('KAMU DI SINI', W * 0.52, H * 0.66 + 56);
  const pins: [string, number, number, string, string][] = [['A', W * 0.4, H * 0.38, '#d62b1f', 'RUMAH SAKIT'], ['B', W * 0.82, H * 0.86, '#1f9d4b', 'POS EVAKUASI']];
  pins.forEach(([k, x, y, col, label]) => {
    const on = hi === k, pulse = on ? 1 + Math.sin(t * 8) * 0.12 : 1;
    g.strokeStyle = col; g.lineWidth = 8; g.setLineDash([22, 16]); g.beginPath(); g.moveTo(W * 0.52, H * 0.66); g.lineTo(x, y); g.stroke(); g.setLineDash([]);
    if (on) { g.fillStyle = col + '55'; g.beginPath(); g.arc(x, y, 90 * pulse, 0, 7); g.fill(); }
    g.fillStyle = col; g.beginPath(); g.arc(x, y, 46 * pulse, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.font = `900 58px ${font}`; g.fillText(k, x, y + 20);
    g.fillStyle = '#111'; g.font = `900 40px ${font}`; g.fillText(label, x, y + 100);
  });
}
