import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {Part2} from './part2/Main2';
import {DURATION2} from './part2/config2';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './config';

export const Root: React.FC = () => (
  <>
    <Composition id="ZombieOutbreak" component={Main} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
    <Composition id="Part2" component={Part2} durationInFrames={DURATION2} fps={FPS} width={WIDTH} height={HEIGHT} />
  </>
);
