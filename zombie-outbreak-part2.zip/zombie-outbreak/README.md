# Zombie Outbreak (Remotion)

Vertikal 1080x1920, 30 FPS, MP4 H.264. Butuh Node 18+.

## Part 1 (komposisi "ZombieOutbreak", tidak diubah)
npm install -> npm run dev -> npm run render  (hasil: out/zombie-outbreak.mp4)

## Part 2 (komposisi "Part2", versi rumah sakit / pilihan A)
1. npm install
2. (sangat disarankan) npm run transcribe2  -> Whisper lokal mengisi src/part2/captions2.json,
   sehingga subtitle memakai kata dari suara asli dan adegan pas dengan narasi.
3. npm run dev2   (preview di Remotion Studio, pilih "Part2")
4. npm run render2  -> out/part2.mp4

Voiceover: public/part2/voiceover2.mp3 (Janu - Calm Narrator, 111 detik).
Naskah yang dipakai ada di src/part2/lines2.json (ganti jika narasimu berbeda).
Posisi kamera per adegan: src/part2/scenes2.tsx (array `keys`).
Render 3D + bayangan cukup berat; pakai `--concurrency=2` kalau RAM kecil.
