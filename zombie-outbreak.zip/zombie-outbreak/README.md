# Zombie Outbreak — Kota Terbengkalai (Remotion)

Vertikal 1080x1920, 30 FPS, MP4 H.264. Voiceover utuh: public/voiceover.mp3.

## Cara pakai
1. `npm install`
2. (disarankan) `npm run transcribe` — sinkronkan subtitle & adegan dengan suara asli (butuh internet sekali).
3. `npm run dev` — preview di Remotion Studio, cek kamera & adegan.
4. `npm run render` — hasil: out/zombie-outbreak.mp4

## Catatan
- Render 3D cukup berat (sekitar 3700 frame). Pakai `--concurrency=2` kalau RAM kecil.
- Posisi kamera tiap adegan ada di src/Scenes.tsx (array `keys`), mudah diubah.
- SFX/musik di public/sfx dibuat otomatis (sederhana); ganti file dengan nama sama jika punya yang lebih bagus.
