// Opsional tapi disarankan: timing subtitle & adegan akurat dari audio (Whisper lokal).
// Jalankan: npm run transcribe  -> mengisi src/captions.json
import {installWhisperCpp, downloadWhisperModel, transcribe, toCaptions} from '@remotion/install-whisper-cpp';
import {execSync} from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';

const to = path.join(process.cwd(), 'whisper.cpp');
await installWhisperCpp({to, version: '1.5.5'});
await downloadWhisperModel({model: 'medium', folder: to});
execSync('npx remotion ffmpeg -i public/voiceover.mp3 -ar 16000 -ac 1 -y public/voiceover-16k.wav', {stdio: 'inherit'});
const out = await transcribe({inputPath: 'public/voiceover-16k.wav', whisperPath: to, whisperCppVersion: '1.5.5', model: 'medium', tokenLevelTimestamps: true, language: 'id'});
const {captions} = toCaptions({whisperCppOutput: out});
fs.writeFileSync('src/captions.json', JSON.stringify(captions, null, 1));
console.log('Selesai:', captions.length, 'token');
