import React, {useEffect, useMemo} from 'react';
import * as THREE from 'three';
import {FPS} from '../config';
import {BASE_H, BASE_W, drawStickman, Emotion, Pose, StickParams} from '../stickman';

export type V3 = [number, number, number];
type CP = Omit<StickParams, 't'>;

export const Character: React.FC<{
  frame: number; pos: V3; h?: number; rotY?: number; res?: number; tint?: string; opacity?: number; shadow?: boolean; tOffset?: number;
} & CP> = ({frame, pos, h = 2.5, rotY = 0, res = 2, tint = '#ffffff', opacity = 1, shadow = true, tOffset = 0, ...cp}) => {
  const {canvas, tex} = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = BASE_W * res; c.height = BASE_H * res;
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return {canvas: c, tex: t};
  }, [res]);
  useEffect(() => () => tex.dispose(), [tex]);
  if (opacity <= 0.001) return null;
  drawStickman(canvas.getContext('2d')!, {...cp, t: frame / FPS + tOffset}, res);
  tex.needsUpdate = true;
  const w = (h * BASE_W) / BASE_H;
  return (
    <group position={pos} rotation={[0, rotY, 0]}>
      <mesh position={[0, h / 2 - (16 / BASE_H) * h, 0]}>
        <planeGeometry args={[w, h]} />
        <meshBasicMaterial map={tex} transparent opacity={opacity} alphaTest={0.02} color={tint} toneMapped={false} />
      </mesh>
      {shadow && (
        <mesh position={[0, 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]} scale={[1, 0.5, 1]}>
          <circleGeometry args={[w * 0.32, 20]} />
          <meshBasicMaterial color="#000" transparent opacity={0.35 * opacity} depthWrite={false} />
        </mesh>
      )}
    </group>
  );
};

// Berjalan dari titik a ke b. Otomatis pilih tampak samping/depan sesuai arah kamera (rotY).
export const Walker: React.FC<{
  frame: number; a: V3; b: V3; speed: number; phase?: number; loop?: boolean; startFrame?: number; rotY?: number;
  pose?: Pose; emotion?: Emotion; color?: string; tint?: string; hold?: 'phone' | 'radio' | null; seed?: number; res?: number;
  afterPose?: Pose; opacity?: number; h?: number;
}> = ({frame, a, b, speed, phase = 0, loop = false, startFrame = 0, rotY = 0, pose = 'walk', emotion = 'neutral', afterPose, opacity = 1, ...rest}) => {
  const t = Math.max(0, frame - startFrame) / FPS;
  if (!loop && frame < startFrame) return null;
  const dx = b[0] - a[0], dz = b[2] - a[2];
  const dist = Math.hypot(dx, dz) || 1;
  let u = (t * speed) / dist + phase;
  const done = !loop && u >= 1;
  u = loop ? u - Math.floor(u) : Math.min(1, u);
  const pos: V3 = [a[0] + dx * u, a[1], a[2] + dz * u];
  const d = [dx / dist, dz / dist];
  const side = d[0] * Math.cos(rotY) - d[1] * Math.sin(rotY);
  const toward = d[0] * Math.sin(rotY) + d[1] * Math.cos(rotY);
  const view = Math.abs(side) > 0.6 ? 'side' : 'front';
  const cur: Pose = done && afterPose ? afterPose : pose;
  const stride = pose === 'run' ? 2.6 : pose === 'zombie' ? 1.0 : 1.5;
  return (
    <Character frame={frame} pos={pos} rotY={rotY} pose={cur} emotion={emotion} view={view} flip={side < 0} back={view === 'front' && toward < 0}
      speed={cur === pose ? speed / stride : 1} opacity={opacity} tOffset={phase * 7} {...rest} />
  );
};
