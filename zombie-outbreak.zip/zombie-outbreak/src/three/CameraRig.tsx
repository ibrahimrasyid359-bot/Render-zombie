import React, {useLayoutEffect} from 'react';
import {useThree} from '@react-three/fiber';
import {Easing, interpolate} from 'remotion';
import * as THREE from 'three';

export type V3 = [number, number, number];
export type Key = {f: number; pos: V3; look: V3; fov?: number};

export const CameraRig: React.FC<{keys: Key[]; frame: number; shake?: number; linear?: boolean}> = ({keys, frame, shake = 1, linear}) => {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  const invalidate = useThree((s) => s.invalidate);
  const fs = keys.map((k) => k.f);
  const opt: any = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'};
  if (!linear) opt.easing = Easing.inOut(Easing.sin);
  const g = (sel: (k: Key) => number) => interpolate(frame, fs, keys.map(sel), opt);
  camera.position.set(g((k) => k.pos[0]) + Math.sin(frame / 53) * 0.035 * shake, g((k) => k.pos[1]) + Math.sin(frame / 37 + 1) * 0.02 * shake, g((k) => k.pos[2]));
  camera.lookAt(g((k) => k.look[0]) + Math.sin(frame / 61) * 0.05 * shake, g((k) => k.look[1]), g((k) => k.look[2]));
  const fov = g((k) => k.fov ?? 50);
  if (camera.fov !== fov) { camera.fov = fov; camera.updateProjectionMatrix(); }
  useLayoutEffect(() => { invalidate(); });
  return null;
};
