import React, {useMemo} from 'react';
import * as THREE from 'three';
import {FPS} from '../config';
import {clamp01, makeFacade, makeGlow, makeLed, makeLit, makeRoad, makeShop, makeSidewalk, mix, rng} from './textures';
import {FONT} from '../fonts';

type V3 = [number, number, number];

/* ---------- Props ---------- */
export const Glow: React.FC<{pos: V3; size: number; color: string; opacity: number; tex: THREE.Texture}> = ({pos, size, color, opacity, tex}) =>
  opacity < 0.02 ? null : (
    <mesh position={pos}>
      <planeGeometry args={[size, size]} />
      <meshBasicMaterial map={tex} color={color} transparent opacity={opacity} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} />
    </mesh>
  );

export const Car: React.FC<{pos: V3; ry?: number; color?: string; lights?: number; scale?: number}> = ({pos, ry = 0, color = '#777', lights = 0, scale = 1}) => (
  <group position={pos} rotation={[0, ry, 0]} scale={scale}>
    <mesh position={[0, 0.62, 0]}><boxGeometry args={[1.85, 0.62, 4.3]} /><meshStandardMaterial color={color} roughness={0.55} metalness={0.35} /></mesh>
    <mesh position={[0, 1.18, -0.2]}><boxGeometry args={[1.62, 0.55, 2.3]} /><meshStandardMaterial color="#14181c" roughness={0.2} metalness={0.6} /></mesh>
    <mesh position={[0, 1.48, -0.2]}><boxGeometry args={[1.6, 0.06, 2.1]} /><meshStandardMaterial color={color} roughness={0.6} /></mesh>
    {[[-0.95, 1.3], [0.95, 1.3], [-0.95, -1.3], [0.95, -1.3]].map(([x, z], i) => (
      <mesh key={i} position={[x, 0.33, z]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.33, 0.33, 0.25, 12]} /><meshStandardMaterial color="#0d0d0d" /></mesh>
    ))}
    {[-0.6, 0.6].map((x) => (
      <React.Fragment key={x}>
        <mesh position={[x, 0.72, 2.16]}><boxGeometry args={[0.4, 0.18, 0.05]} /><meshBasicMaterial color={mix('#111', '#fff6d8', lights)} /></mesh>
        <mesh position={[x, 0.72, -2.16]}><boxGeometry args={[0.4, 0.16, 0.05]} /><meshBasicMaterial color={mix('#2a0505', '#ff2a1a', lights)} /></mesh>
      </React.Fragment>
    ))}
  </group>
);

export const Bus: React.FC<{pos: V3; ry?: number}> = ({pos, ry = 0}) => (
  <group position={pos} rotation={[0, ry, 0]}>
    <mesh position={[0, 1.75, 0]}><boxGeometry args={[2.6, 3, 11]} /><meshStandardMaterial color="#8a2f2f" roughness={0.7} /></mesh>
    <mesh position={[0, 1.2, 0]}><boxGeometry args={[2.62, 0.5, 11.02]} /><meshStandardMaterial color="#d8d6cc" /></mesh>
    {[-1.31, 1.31].map((x) => <mesh key={x} position={[x, 2.4, 0]}><boxGeometry args={[0.05, 1.05, 9.6]} /><meshStandardMaterial color="#0c1013" roughness={0.2} /></mesh>)}
    <mesh position={[0, 2.4, 5.52]}><boxGeometry args={[2.2, 1.1, 0.05]} /><meshStandardMaterial color="#0c1013" /></mesh>
  </group>
);

export const Ambulance: React.FC<{pos: V3; ry?: number; frame: number}> = ({pos, ry = 0, frame}) => {
  const on = Math.floor(frame / 8) % 2;
  return (
    <group position={pos} rotation={[0, ry, 0]}>
      <mesh position={[0, 1.4, 0]}><boxGeometry args={[2.1, 2.2, 5.5]} /><meshStandardMaterial color="#e6e6e1" roughness={0.6} /></mesh>
      <mesh position={[0, 0.9, 0]}><boxGeometry args={[2.12, 0.35, 5.52]} /><meshStandardMaterial color="#b52a22" /></mesh>
      <mesh position={[0, 1.7, 2.76]}><boxGeometry args={[1.8, 0.7, 0.05]} /><meshStandardMaterial color="#0c1013" /></mesh>
      <mesh position={[-0.5, 2.6, 2]}><boxGeometry args={[0.6, 0.18, 0.3]} /><meshBasicMaterial color={on ? '#ff2a1a' : '#3a0a08'} /></mesh>
      <mesh position={[0.5, 2.6, 2]}><boxGeometry args={[0.6, 0.18, 0.3]} /><meshBasicMaterial color={on ? '#101840' : '#3a6bff'} /></mesh>
      {[-1.07, 1.07].map((x) => <mesh key={x} position={[x, 1.6, -0.5]} rotation={[0, Math.PI / 2, 0]}><planeGeometry args={[0.9, 0.9]} /><meshBasicMaterial color="#c0261d" side={THREE.DoubleSide} /></mesh>)}
    </group>
  );
};

/* ---------- Dunia kota ---------- */
type B = {x: number; z: number; w: number; h: number; d: number; v: number; side: number; row: number; shop: number; geo: THREE.BufferGeometry; roof: V3[]; ant: boolean};
function boxGeo(w: number, h: number, d: number) {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) {
    const i = f * 4 + k;
    const [su, sv] = f < 2 ? [d / 16, h / 24] : f < 4 ? [w / 16, d / 16] : [w / 16, h / 24];
    uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv);
  }
  uv.needsUpdate = true;
  return g;
}
function genBuildings(seed: number): B[] {
  const r = rng(seed), out: B[] = [];
  for (const side of [-1, 1]) for (const row of [0, 1]) {
    let z = 22 - r() * 6;
    while (z > -250) {
      const d = 14 + r() * 10, w = 14 + r() * 10;
      const h = row === 0 ? 22 + r() * 40 : 45 + r() * 70;
      const x = side * ((row === 0 ? 11 : 37) + w / 2);
      const roof: V3[] = [0, 1, 2].filter(() => r() < 0.6).map(() => [(r() - 0.5) * w * 0.6, 0.8, (r() - 0.5) * d * 0.6] as V3);
      out.push({x, z: z - d / 2, w, h, d, v: (r() * 4) | 0, side, row, shop: (r() * 4) | 0, geo: boxGeo(w, h, d), roof, ant: r() < 0.35});
      z -= d + 1 + r() * 3;
    }
  }
  const s = rng(seed + 9);
  for (let i = 0; i < 16; i++) {
    const w = 18 + s() * 16, h = 70 + s() * 100, d = 20;
    out.push({x: -100 + i * 13 + s() * 6, z: -260 - s() * 80, w, h, d, v: 3, side: 0, row: 2, shop: 0, geo: boxGeo(w, h, d), roof: [], ant: s() < 0.4});
  }
  return out;
}

export type WorldProps = {
  frame: number; power: number; day: number; abandoned: number; traffic?: number; fogColor: string; fogNear?: number; fogFar?: number;
  skipLeft?: [number, number]; ambulance?: boolean; led?: number; children?: React.ReactNode;
};

export const World: React.FC<WorldProps> = ({frame, power, day, abandoned, traffic = 0, fogColor, fogNear = 25, fogFar = 260, skipLeft, ambulance, led = 0, children}) => {
  const damage = abandoned > 0.75 ? 1 : 0;
  const A = useMemo(() => {
    const road = makeRoad(damage); road.repeat.set(1, 420 / 28);
    const side = makeSidewalk(); side.repeat.set(1, 105);
    const facades = [0, 1, 2, 3].map((v) => makeFacade(v, damage));
    const lits = [0, 1, 2, 3].map((v) => makeLit(v));
    const mats = facades.map((f, v) => new THREE.MeshStandardMaterial({map: f, emissiveMap: lits[v], emissive: new THREE.Color('#fff'), emissiveIntensity: 0, roughness: 0.85, metalness: 0.05}));
    const roofMat = new THREE.MeshStandardMaterial({color: '#2a2d30', roughness: 0.95});
    const shops = [0, 1, 2, 3].map((v) => makeShop(v));
    const shopMats = shops.map((s) => new THREE.MeshStandardMaterial({map: s.map, emissiveMap: s.lit, emissive: new THREE.Color('#fff'), emissiveIntensity: 0, roughness: 0.8}));
    return {road, side, mats, roofMat, shopMats, glow: makeGlow(), led: makeLed(FONT), blds: genBuildings(42)};
  }, [damage]);
  const stat = useMemo(() => {
    const r = rng(7);
    const lanes = [-5.4, -2.3, 2.3, 5.4], cols = ['#6b6f73', '#8a2d2d', '#4a5a4a', '#6b5a46', '#c9c5b8', '#2f3a46'];
    const cars = Array.from({length: 34}, (_, i) => ({pos: [lanes[(r() * 4) | 0] + (r() - 0.5) * 0.6, 0, 8 - r() * 170] as V3, ry: (r() - 0.5) * 0.5 + (i % 9 === 0 ? 0.9 : 0) + (r() < 0.5 ? 0 : Math.PI), color: cols[(r() * 6) | 0]}));
    const trash = Array.from({length: 70}, () => ({p: [(r() - 0.5) * 20, 0.08, 6 - r() * 90] as V3, s: 0.15 + r() * 0.35, c: ['#c9c5b8', '#7a6a55', '#3a5a7a', '#8a3a3a'][(r() * 4) | 0], ry: r() * 3}));
    const grass = Array.from({length: 130}, () => ({p: [(r() < 0.5 ? -1 : 1) * (6.6 + r() * 4.6), 0.2, 8 - r() * 110] as V3, s: 0.6 + r() * 1.2}));
    const trf = Array.from({length: 14}, (_, i) => ({lane: [2.4, 5.2, -2.4, -5.2][i % 4], z0: r() * 225, v: 7 + r() * 4, color: cols[(r() * 6) | 0]}));
    return {cars, trash, grass, trf};
  }, []);

  const {mats, shopMats, roofMat, glow, blds} = A;
  mats.forEach((m, v) => { m.emissiveIntensity = clamp01((power * 1.4 - v * 0.25) * 2.5) * 1.25 * (1 - day * 0.6); });
  shopMats.forEach((m) => { m.emissiveIntensity = power * 1.1; });
  const t = frame / FPS;
  const lampPow = (i: number) => clamp01((power * 1.3 - i / 10) * 3);
  const nCars = Math.round(34 * abandoned);
  const ledB = blds.filter((b) => b.side === -1 && b.row === 0).sort((a, b) => Math.abs(a.z + 45) - Math.abs(b.z + 45))[0];

  return (
    <group>
      <fog attach="fog" args={[fogColor, fogNear, fogFar]} />
      <hemisphereLight args={[mix('#5566aa', '#cfd6d8', day), mix('#14141c', '#4b4f48', day), 0.55 + day * 0.5]} />
      <directionalLight position={[-30, 60, 25]} intensity={0.45 + day * 0.9} color={mix('#9fb4ff', '#f2f0e6', day)} />
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.02, -150]}><planeGeometry args={[600, 600]} /><meshStandardMaterial color="#2b2d29" /></mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0, -190]}><planeGeometry args={[14, 420]} /><meshStandardMaterial map={A.road} roughness={0.92} /></mesh>
      {[-9, 9].map((x) => <mesh key={x} position={[x, 0.08, -190]}><boxGeometry args={[4, 0.16, 420]} /><meshStandardMaterial map={A.side} roughness={0.95} /></mesh>)}

      {blds.map((b, i) => {
        if (skipLeft && b.side === -1 && b.row < 2 && b.z + b.d / 2 > skipLeft[0] && b.z - b.d / 2 < skipLeft[1]) return null;
        const m = mats[b.v];
        const sv = abandoned > 0.75 ? (b.shop < 2 ? 1 : b.shop) : b.shop === 1 ? 0 : b.shop;
        return (
          <group key={i}>
            <mesh position={[b.x, b.h / 2, b.z]} geometry={b.geo} material={[m, m, roofMat, roofMat, m, m]} />
            {b.roof.map((r, k) => <mesh key={k} position={[b.x + r[0], b.h + r[1], b.z + r[2]]}><boxGeometry args={[3, 1.6, 3]} /><meshStandardMaterial color="#3a3d40" /></mesh>)}
            {b.ant && <mesh position={[b.x, b.h + 5, b.z]}><cylinderGeometry args={[0.1, 0.15, 10, 6]} /><meshStandardMaterial color="#555" /></mesh>}
            {b.ant && <mesh position={[b.x, b.h + 10.2, b.z]}><sphereGeometry args={[0.35, 8, 8]} /><meshBasicMaterial color={Math.floor(t * 1.2) % 2 ? '#ff2a1a' : '#400a08'} /></mesh>}
            {b.row === 0 && (
              <mesh position={[b.side * 10.95, 2.2, b.z]} rotation={[0, -b.side * Math.PI / 2, 0]}>
                <planeGeometry args={[b.d - 1, 4.4]} /><primitive object={shopMats[sv]} attach="material" />
              </mesh>
            )}
          </group>
        );
      })}

      {ledB && led > 0.01 && (
        <mesh position={[-10.85, 14, ledB.z]} rotation={[0, Math.PI / 2, 0]}>
          <planeGeometry args={[Math.min(ledB.d - 2, 12), 6]} />
          <meshBasicMaterial map={A.led} color={mix('#000', '#fff', led)} toneMapped={false} />
        </mesh>
      )}

      {[-1, 1].flatMap((s) => Array.from({length: 10}, (_, i) => ({s, i}))).map(({s, i}) => {
        const z = 14 - i * 22, x = s * 7.7, lp = lampPow(i);
        return (
          <group key={`${s}${i}`}>
            <mesh position={[x, 3.75, z]}><cylinderGeometry args={[0.08, 0.1, 7.5, 6]} /><meshStandardMaterial color="#3b3d3f" /></mesh>
            <mesh position={[x - s * 0.9, 7.4, z]}><boxGeometry args={[1.8, 0.08, 0.08]} /><meshStandardMaterial color="#3b3d3f" /></mesh>
            <mesh position={[x - s * 1.7, 7.3, z]}><sphereGeometry args={[0.22, 8, 8]} /><meshBasicMaterial color={mix('#222', '#ffe2a8', lp)} /></mesh>
            <Glow pos={[x - s * 1.7, 7.3, z]} size={6} color="#ffd68a" opacity={lp * 0.55} tex={glow} />
          </group>
        );
      })}

      {Array.from({length: 7}, (_, i) => [-1, 1].map((s) => (
        <group key={`${s}${i}`} position={[s * 9.8, 0, 2 - i * 30 - (s > 0 ? 12 : 0)]}>
          <mesh position={[0, 1.5, 0]}><cylinderGeometry args={[0.2, 0.26, 3, 6]} /><meshStandardMaterial color="#3c2f25" /></mesh>
          <mesh position={[0, 4.4, 0]} scale={[1, 0.9, 1]}><icosahedronGeometry args={[2.3, 0]} /><meshStandardMaterial color={mix('#355a2f', '#4a553f', abandoned * 0.6)} roughness={1} /></mesh>
        </group>
      )))}

      {[-1, 1].map((s) => (
        <group key={s} position={[s * 7.4, 0, -26]}>
          <mesh position={[0, 2.6, 0]}><cylinderGeometry args={[0.07, 0.07, 5.2, 6]} /><meshStandardMaterial color="#444" /></mesh>
          <mesh position={[0, 5.0, 0]}><boxGeometry args={[0.4, 1.2, 0.35]} /><meshStandardMaterial color="#222" /></mesh>
          <mesh position={[0, 5.4, 0.2]}><sphereGeometry args={[0.13, 8, 8]} /><meshBasicMaterial color={power > 0.3 && abandoned < 0.3 ? '#ff2a1a' : '#2a0a08'} /></mesh>
          <Glow pos={[0, 5.4, 0.3]} size={2} color="#ff3a22" opacity={power > 0.3 && abandoned < 0.3 ? 0.7 : 0} tex={glow} />
        </group>
      ))}

      {stat.cars.slice(0, nCars).map((c, i) => <Car key={i} pos={c.pos} ry={c.ry} color={mix(c.color, '#6a6e68', 0.35)} lights={0} />)}
      {abandoned > 0.3 && <Bus pos={[-2.6, 0, -34]} ry={0.12} />}
      {ambulance && <Ambulance frame={frame} pos={[-3.4, 0, -26]} ry={0.35} />}
      {stat.trash.slice(0, Math.floor(70 * abandoned)).map((o, i) => <mesh key={i} position={o.p} rotation={[0, o.ry, 0]}><boxGeometry args={[o.s, 0.06, o.s * 0.7]} /><meshStandardMaterial color={o.c} roughness={1} /></mesh>)}
      {stat.grass.slice(0, Math.floor(130 * abandoned * abandoned)).map((o, i) => <mesh key={i} position={o.p} scale={o.s}><coneGeometry args={[0.14, 0.7, 4]} /><meshStandardMaterial color="#566b3a" roughness={1} /></mesh>)}
      {traffic > 0 && stat.trf.slice(0, Math.round(14 * traffic)).map((c, i) => {
        const dir = c.lane > 0 ? 1 : -1;
        const z = -200 + ((((c.z0 + dir * c.v * t) % 225) + 225) % 225);
        return <Car key={i} pos={[c.lane, 0, z]} ry={dir > 0 ? 0 : Math.PI} color={c.color} lights={1} />;
      })}
      {children}
    </group>
  );
};
