import React, {useEffect, useMemo} from 'react';
import * as THREE from 'three';
import {FPS} from '../config';
import {FONT} from '../fonts';
import {clamp01, drawMap, makeChecker, makeGlow, makeTrainSide, mix, rng, toTex} from './textures';

type V3 = [number, number, number];
const Box: React.FC<{p: V3; s: V3; c: string; rough?: number}> = ({p, s, c, rough = 0.9}) => (
  <mesh position={p}><boxGeometry args={s} /><meshStandardMaterial color={c} roughness={rough} /></mesh>
);

/* ---------- Minimarket (menempel di sisi kiri jalan, jendela di x=-11) ---------- */
const Shelf: React.FC<{p: V3; ry?: number; seed: number}> = ({p, ry = 0, seed}) => {
  const items = useMemo(() => {
    const r = rng(seed), cols = ['#a33', '#37a', '#3a6', '#cb3', '#c73', '#ddd', '#76a'];
    return Array.from({length: 40}, (_, i) => ({x: (i % 10) * 0.4 - 1.8, y: 0.35 + Math.floor(i / 10) * 0.45, c: cols[(r() * cols.length) | 0], h: 0.2 + r() * 0.15, on: r() < 0.82}));
  }, [seed]);
  return (
    <group position={p} rotation={[0, ry, 0]}>
      <Box p={[0, 1, 0]} s={[4.2, 2, 0.7]} c="#555a5c" />
      {items.filter((i) => i.on).map((i, k) => <mesh key={k} position={[i.x, i.y, 0.38]}><boxGeometry args={[0.3, i.h, 0.2]} /><meshStandardMaterial color={i.c} roughness={0.8} /></mesh>)}
    </group>
  );
};

export const MapPoster: React.FC<{frame: number; hi: 'none' | 'A' | 'B'}> = ({frame, hi}) => {
  const {c, tex} = useMemo(() => {
    const c = document.createElement('canvas'); c.width = 768; c.height = 1050;
    return {c, tex: toTex(c, false)};
  }, []);
  drawMap(c, hi, frame / FPS, FONT);
  tex.needsUpdate = true;
  return <mesh position={[-20.74, 1.6, -7.5]} rotation={[0, Math.PI / 2, 0]}><planeGeometry args={[1.5, 2.05]} /><meshBasicMaterial map={tex} toneMapped={false} /></mesh>;
};

export const ShopSet: React.FC<{frame: number; radio: number}> = ({frame, radio}) => {
  const checker = useMemo(() => { const t = makeChecker(); t.repeat.set(5, 7.5); return t; }, []);
  const glow = useMemo(() => makeGlow(), []);
  const flick = Math.sin(frame * 1.7) > 0.5 ? 1 : 0.35;
  const dial = radio * (0.6 + 0.4 * Math.sin(frame * 0.9));
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[-16, 0.02, -7.5]}><planeGeometry args={[10, 15]} /><meshStandardMaterial map={checker} roughness={0.7} /></mesh>
      <Box p={[-21, 2, -7.5]} s={[0.4, 4, 15]} c="#9a9d92" />
      <Box p={[-16, 2, 0.1]} s={[10, 4, 0.3]} c="#8c8f85" />
      <Box p={[-16, 2, -15.1]} s={[10, 4, 0.3]} c="#8c8f85" />
      <Box p={[-16, 3.75, -7.5]} s={[10, 0.3, 15]} c="#6f7268" />
      <Box p={[-11, 0.45, -7.5]} s={[0.3, 0.9, 15]} c="#4b4e50" />
      <Box p={[-11, 3.15, -7.5]} s={[0.3, 1.2, 15]} c="#3e4143" />
      {[-0.2, -5, -10, -14.8].map((z) => <Box key={z} p={[-11, 1.8, z]} s={[0.3, 3.6, 0.35]} c="#2c2e30" />)}
      <mesh position={[-11.02, 1.8, -7.5]} rotation={[0, Math.PI / 2, 0]}><planeGeometry args={[15, 1.8]} /><meshStandardMaterial color="#9fb5b0" transparent opacity={0.1} roughness={0.05} /></mesh>
      {[-3, 1.5].map((z, i) => <Shelf key={i} p={[-17.5, 0, z - 9 * i - 3]} seed={i + 3} />)}
      <Shelf p={[-17.5, 0, -12.6]} seed={9} />
      <Box p={[-16.2, 0.5, -2.2]} s={[4, 1, 0.8]} c="#6d5a45" />
      <Box p={[-17.6, 1.15, -2.3]} s={[0.5, 0.3, 0.4]} c="#222" />
      {/* radio */}
      <group position={[-16.2, 1.14, -2.25]}>
        <mesh><boxGeometry args={[0.5, 0.28, 0.2]} /><meshStandardMaterial color="#7a5c3a" roughness={0.8} /></mesh>
        <mesh position={[-0.1, 0, -0.105]}><planeGeometry args={[0.22, 0.2]} /><meshBasicMaterial color="#1c1612" /></mesh>
        <mesh position={[0.14, 0.02, -0.105]}><circleGeometry args={[0.045, 14]} /><meshBasicMaterial color={mix('#3a2410', '#ffb347', dial)} /></mesh>
        <mesh position={[0.2, 0.3, 0]} rotation={[0, 0, -0.35]}><cylinderGeometry args={[0.006, 0.006, 0.6, 5]} /><meshStandardMaterial color="#ccc" /></mesh>
        <Glow3 pos={[0.14, 0.02, -0.2]} dial={dial} tex={glow} />
      </group>
      <pointLight position={[-16, 3.2, -7.5]} intensity={6 * flick} distance={12} color="#cfe8ff" />
      <Box p={[-16, 3.55, -5]} s={[1.6, 0.06, 0.2]} c={mix('#222', '#dfeaff', flick * 0.5)} />
    </group>
  );
};
const Glow3: React.FC<{pos: V3; dial: number; tex: THREE.Texture}> = ({pos, dial, tex}) => (
  <mesh position={pos}><planeGeometry args={[0.7, 0.7]} /><meshBasicMaterial map={tex} color="#ffa63a" transparent opacity={dial * 0.7} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} /></mesh>
);

/* ---------- Stasiun KRL ---------- */
export const StationSet: React.FC<{frame: number; power: number}> = ({frame, power}) => {
  const train = useMemo(() => { const t = makeTrainSide(); t.repeat.set(5, 1); return t; }, []);
  const floor = useMemo(() => { const t = makeChecker(); t.repeat.set(5, 35); return t; }, []);
  const sign = useMemo(() => {
    const c = document.createElement('canvas'); c.width = 512; c.height = 128;
    const g = c.getContext('2d')!; g.fillStyle = '#1b4d8f'; g.fillRect(0, 0, 512, 128);
    g.fillStyle = '#fff'; g.font = `900 64px ${FONT}`; g.textAlign = 'center'; g.fillText('STASIUN KOTA', 256, 85);
    return toTex(c, false);
  }, []);
  const flick = power > 0.01 && power < 0.99 ? (Math.sin(frame * 2.1) > 0 ? 1 : 0.2) : 1;
  const lp = power * flick;
  const red = Math.floor(frame / 15) % 2 ? 1 : 0.2;
  return (
    <group>
      <fog attach="fog" args={['#1a211e', 8, 75]} />
      <hemisphereLight args={['#6c8a8a', '#101412', 0.35 + 0.3 * lp]} />
      <mesh rotation-x={-Math.PI / 2} position={[-1.5, 0, -25]}><planeGeometry args={[10, 70]} /><meshStandardMaterial map={floor} roughness={0.8} /></mesh>
      <Box p={[3.0, 0.02, -25]} s={[0.5, 0.02, 70]} c="#d9b52b" />
      <Box p={[4.0, -1.1, -25]} s={[2.4, 0.2, 70]} c="#2a2724" />
      {[3.4, 4.6].map((x) => <Box key={x} p={[x - 0.3, -0.9, -25]} s={[0.12, 0.15, 70]} c="#6b6b68" />)}
      <mesh position={[4.15, 1.9, -22.5]} rotation={[0, -Math.PI / 2, 0]}><planeGeometry args={[65, 3.4]} /><meshStandardMaterial map={train} roughness={0.5} metalness={0.3} /></mesh>
      <Box p={[5.8, 2.0, -22.5]} s={[3, 3.2, 65]} c="#2b2f33" />
      <Box p={[-7, 3, -25]} s={[0.3, 6, 70]} c="#5c605a" />
      <Box p={[0, 5.5, -25]} s={[15, 0.3, 70]} c="#3a3e3b" />
      <mesh position={[-6.8, 4.2, -12]} rotation={[0, Math.PI / 2, 0]}><planeGeometry args={[4, 1]} /><meshBasicMaterial map={sign} color={mix('#000', '#fff', lp * 0.9 + 0.08)} /></mesh>
      {Array.from({length: 7}, (_, i) => (
        <group key={i}>
          <mesh position={[-3, 2.75, 6 - i * 10]}><cylinderGeometry args={[0.25, 0.25, 5.5, 8]} /><meshStandardMaterial color="#555a58" /></mesh>
          <Box p={[0, 5.25, 6 - i * 10]} s={[1.6, 0.08, 0.3]} c={mix('#1a1e1c', '#e6f0ff', lp)} />
        </group>
      ))}
      <Box p={[-5.5, 0.45, -14]} s={[0.6, 0.9, 3]} c="#4d3f33" />
      <pointLight position={[0, 4.8, -8]} intensity={40 * lp} distance={30} color="#dfeaff" />
      <pointLight position={[0, 4.6, -26]} intensity={40 * lp} distance={30} color="#dfeaff" />
      <pointLight position={[1, 4.4, -12]} intensity={(1 - lp) * 22 * red} distance={26} color="#ff2a1a" />
    </group>
  );
};
