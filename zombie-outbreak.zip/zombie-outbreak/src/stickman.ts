// Gambar stickman 2D ke canvas (dipakai sebagai billboard di dunia 3D).
export type Emotion = 'neutral' | 'scared' | 'panic' | 'confused' | 'sad' | 'shock' | 'zombie';
export type Pose = 'stand' | 'walk' | 'run' | 'zombie' | 'handsup' | 'hold' | 'point';
export type StickParams = {
  t: number; pose: Pose; emotion: Emotion; view?: 'side' | 'front'; flip?: boolean; back?: boolean;
  speed?: number; color?: string; hold?: 'phone' | 'radio' | null; silhouette?: boolean; look?: number; seed?: number;
};
export const BASE_W = 256;
export const BASE_H = 420;
type P = [number, number];
const rad = (d: number) => (d * Math.PI) / 180;
const J = (p: P, a: number, l: number): P => [p[0] + Math.sin(a) * l, p[1] + Math.cos(a) * l];

export function drawStickman(ctx: CanvasRenderingContext2D, o: StickParams, res = 2) {
  const W = BASE_W * res, H = BASE_H * res;
  ctx.clearRect(0, 0, W, H);
  const view = o.view ?? 'side';
  const zombie = o.pose === 'zombie';
  const sil = !!o.silhouette;
  const line = sil ? '#050505' : o.color ?? (zombie ? '#a8b894' : '#f1f1ec');
  const skin = sil ? '#050505' : zombie ? '#8fa27c' : '#f7f3e8';
  const speed = o.speed ?? (o.pose === 'run' ? 1.5 : zombie ? 0.55 : 1);
  const t = o.t;
  const p = t * speed * Math.PI * 2;
  const moving = o.pose === 'walk' || o.pose === 'run' || zombie;
  ctx.save();
  const k = 1.9 * res;
  ctx.translate(W / 2, H - 16 * res);
  ctx.scale(o.flip ? -k : k, k);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const segs: P[][] = [];
  const hands: P[] = [];
  let head: P;
  let handObj: P | null = null;
  let shiftY = 0;

  if (view === 'side') {
    const hip: P = [0, -78];
    let lean = 0, tilt = 0;
    let th: [number, number] = [-0.07, 0.07], sh: [number, number] = [-0.07, 0.07];
    let ua: [number, number] = [0, 0], la: [number, number] = [0, 0];
    const sw = Math.sin(t * 1.8) * rad(2);
    if (o.pose === 'walk' || o.pose === 'run') {
      const run = o.pose === 'run';
      const A = rad(run ? 52 : 32), B = rad(run ? 75 : 40), AA = rad(run ? 60 : 28), E = rad(run ? 85 : 15);
      lean = rad(run ? 13 : 3);
      for (let i = 0; i < 2; i++) {
        const ph = p + i * Math.PI;
        th[i] = Math.sin(ph) * A;
        sh[i] = th[i] - B * Math.max(0, Math.cos(ph));
        ua[i] = -Math.sin(ph) * AA;
        la[i] = ua[i] + E;
      }
    } else if (zombie) {
      lean = rad(14);
      tilt = rad(20) + Math.sin(t * 3) * rad(3);
      th = [Math.sin(p) * rad(24) + rad(8), -rad(10) + Math.sin(p + Math.PI) * rad(14)];
      sh = [th[0] - rad(30) * Math.max(0, Math.cos(p)), th[1] + rad(10)];
      ua = [rad(82) + Math.sin(p * 0.5) * rad(7), rad(95) + Math.sin(p * 0.5 + 2) * rad(7)];
      la = [ua[0] + rad(8), ua[1] + rad(8)];
    } else if (o.pose === 'handsup') {
      const tr = Math.sin(t * 28) * rad(3);
      th = [-0.14, 0.14]; sh = th;
      ua = [rad(155) + tr, rad(165) - tr];
      la = [ua[0] + rad(15), ua[1] + rad(10)];
    } else if (o.pose === 'hold') {
      ua = [rad(40), rad(4)]; la = [rad(120), rad(10)];
    } else if (o.pose === 'point') {
      ua = [rad(90), rad(4)]; la = [rad(92), rad(10)];
    } else {
      ua = [-0.07 + sw, 0.09 - sw]; la = [ua[0] + 0.1, ua[1] + 0.1];
    }
    const legs = [0, 1].map((i) => {
      const knee = J(hip, th[i], 40);
      return [hip, knee, J(knee, sh[i], 38)] as P[];
    });
    shiftY = -Math.max(legs[0][2][1], legs[1][2][1]);
    legs.forEach((l) => segs.push(l));
    const dir: P = [Math.sin(lean), -Math.cos(lean)];
    const neck: P = [hip[0] + dir[0] * 54, hip[1] + dir[1] * 54];
    const S: P = [hip[0] + dir[0] * 46, hip[1] + dir[1] * 46];
    segs.push([hip, neck]);
    for (let i = 0; i < 2; i++) {
      const el = J(S, ua[i] + lean, 28);
      const hd = J(el, la[i] + lean, 28);
      segs.push([S, el, hd]);
      hands.push(hd);
      if (i === 0 && o.hold) handObj = hd;
    }
    head = [neck[0] + Math.sin(lean + tilt) * 22, neck[1] - Math.cos(lean + tilt) * 22];
  } else {
    const sway = moving ? Math.sin(p) * 3.5 : 0;
    const still = !moving;
    const lift = (ph: number) => (still ? 0 : Math.max(0, Math.sin(ph)) * (o.pose === 'run' ? 18 : 12));
    for (let i = 0; i < 2; i++) {
      const sg = i ? 1 : -1;
      const l = lift(p + i * Math.PI);
      segs.push([[sg * 6 + sway, -78], [sg * 9 + sway, -40 - l * 0.8], [sg * 9 + sway, -l]]);
    }
    const nx = sway * 1.3;
    segs.push([[sway, -78], [nx, -132]]);
    for (let i = 0; i < 2; i++) {
      const sg = i ? 1 : -1;
      const S: P = [nx + sg * 10, -124];
      const sw = moving && !zombie ? Math.sin(p + i * Math.PI) * (o.pose === 'run' ? 16 : 8) : 0;
      let el: P, hd: P;
      if (zombie) {
        el = [S[0] + sg * 18, -112 + Math.sin(p * 0.5 + i) * 3];
        hd = [S[0] + sg * 32, -126 + Math.sin(p * 0.5 + i * 2) * 4];
      } else if (o.pose === 'handsup') {
        const tr = Math.sin(t * 28 + i) * 2;
        el = [S[0] + sg * 20, -142 + tr]; hd = [S[0] + sg * 24, -176 + tr];
      } else if (o.pose === 'hold' && i === 0) {
        el = [S[0] - 14, -104]; hd = [S[0] - 3, -113];
        if (o.hold) handObj = hd;
      } else {
        el = [S[0] + sg * 8, -100 + sw * 0.5]; hd = [S[0] + sg * 10, -76 + sw];
      }
      segs.push([S, el, hd]);
      hands.push(hd);
    }
    head = [nx * 1.2 + (zombie ? Math.sin(p * 0.5) * 4 : 0), zombie ? -148 : -154];
  }

  ctx.translate(0, shiftY);
  const stroke = (w: number, col: string) => {
    ctx.strokeStyle = col; ctx.lineWidth = w;
    for (const s of segs) { ctx.beginPath(); ctx.moveTo(s[0][0], s[0][1]); for (let i = 1; i < s.length; i++) ctx.lineTo(s[i][0], s[i][1]); ctx.stroke(); }
  };
  if (!sil) stroke(11, '#0a0a0a');
  stroke(6.5, line);
  if (zombie) { ctx.fillStyle = line; hands.forEach((h) => { ctx.beginPath(); ctx.arc(h[0], h[1], 4.5, 0, 7); ctx.fill(); }); }

  // head
  ctx.beginPath(); ctx.arc(head[0], head[1], 20, 0, Math.PI * 2);
  if (!sil) { ctx.lineWidth = 11; ctx.strokeStyle = '#0a0a0a'; ctx.stroke(); }
  ctx.fillStyle = skin; ctx.fill(); ctx.lineWidth = 6.5; ctx.strokeStyle = line; ctx.stroke();
  if (!o.back) face(ctx, head[0], head[1], o.emotion, t, view === 'side' ? 6 : 0, o.look ?? 0, sil, o.seed ?? 0);

  if (handObj && o.hold) {
    ctx.save(); ctx.translate(handObj[0], handObj[1]);
    if (o.hold === 'phone') {
      ctx.fillStyle = '#111'; ctx.fillRect(-5, -17, 10, 18);
      ctx.fillStyle = '#6fb7ff'; ctx.fillRect(-4, -16, 8, 13);
      ctx.fillStyle = Math.floor(t * 3) % 2 ? '#ff3b30' : '#7a1d17'; ctx.fillRect(-3.4, -15, 6, 2.2);
    } else {
      ctx.fillStyle = '#6b4f2e'; ctx.fillRect(-11, -12, 22, 14);
      ctx.fillStyle = '#222'; ctx.fillRect(-9, -10, 10, 10);
      ctx.fillStyle = '#ffb347'; ctx.beginPath(); ctx.arc(5, -5, 2.6, 0, 7); ctx.fill();
      ctx.strokeStyle = '#cfcfcf'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(8, -12); ctx.lineTo(14, -28); ctx.stroke();
    }
    ctx.restore();
  }
  ctx.restore();
}

function face(ctx: CanvasRenderingContext2D, hx: number, hy: number, emo: Emotion, t: number, shift: number, look: number, sil: boolean, seed: number) {
  const cx = hx + shift, ey = hy - 3;
  const ex = [cx - 7.5, cx + 7.5];
  if (sil) {
    ctx.save(); ctx.shadowColor = '#ff2a1a'; ctx.shadowBlur = 14; ctx.fillStyle = '#ff3b24';
    ex.forEach((x) => { ctx.beginPath(); ctx.arc(x, ey, 3.6, 0, 7); ctx.fill(); });
    ctx.restore(); return;
  }
  const z = emo === 'zombie';
  const r = emo === 'shock' ? 7.2 : emo === 'panic' ? 6.6 : emo === 'scared' ? 5.9 : 5.2;
  const blink = !z && (t * 1000 + seed * 700) % 3400 < 130;
  ctx.strokeStyle = '#111'; ctx.lineWidth = 1.7;
  ex.forEach((x, i) => {
    if (blink) { ctx.beginPath(); ctx.moveTo(x - 4, ey); ctx.lineTo(x + 4, ey); ctx.stroke(); return; }
    ctx.fillStyle = z ? '#d62b1f' : '#fff';
    ctx.beginPath(); ctx.arc(x, ey, r, 0, 7); ctx.fill(); ctx.stroke();
    ctx.fillStyle = z ? '#2a0505' : '#111';
    const wob = emo === 'confused' ? Math.sin(t * 3 + i) * 1.4 : 0;
    ctx.beginPath(); ctx.arc(x + look * 2.4 + wob, ey, emo === 'shock' ? 1.6 : z ? 2.2 : 2.7, 0, 7); ctx.fill();
  });
  // alis
  ctx.lineWidth = 2.2;
  ex.forEach((x, i) => {
    const s = i ? 1 : -1, by = ey - r - 4;
    let inner = by, outer = by;
    if (emo === 'scared' || emo === 'panic' || emo === 'sad') { inner = by - 3; outer = by + 1; }
    else if (z) { inner = by + 2; outer = by - 3; }
    else if (emo === 'confused' && i === 1) { inner = by - 3; outer = by - 3; }
    else if (emo === 'shock') { inner = by - 3; outer = by - 3; }
    ctx.beginPath(); ctx.moveTo(x - s * 4.5, inner); ctx.lineTo(x + s * 4.5, outer); ctx.stroke();
  });
  const my = hy + 9;
  ctx.fillStyle = '#2a0c0c'; ctx.lineWidth = 2.4;
  ctx.beginPath();
  if (emo === 'neutral') { ctx.moveTo(cx - 5, my); ctx.lineTo(cx + 5, my); ctx.stroke(); }
  else if (emo === 'scared') { ctx.ellipse(cx, my, 3.5, 4 + Math.sin(t * 14) * 0.6, 0, 0, 7); ctx.fill(); ctx.stroke(); }
  else if (emo === 'panic') { ctx.ellipse(cx, my + 1, 6, 5 + Math.sin(t * 18) * 1.5, 0, 0, 7); ctx.fill(); ctx.stroke(); }
  else if (emo === 'confused') { ctx.moveTo(cx - 6, my); ctx.quadraticCurveTo(cx - 3, my - 3, cx, my); ctx.quadraticCurveTo(cx + 3, my + 3, cx + 6, my); ctx.stroke(); }
  else if (emo === 'sad') { ctx.arc(cx, my + 6, 6, Math.PI, 2 * Math.PI); ctx.stroke(); }
  else if (emo === 'shock') { ctx.ellipse(cx, my + 1, 4, 6, 0, 0, 7); ctx.fill(); ctx.stroke(); }
  else {
    ctx.moveTo(cx - 8, my - 1);
    for (let i = 0; i <= 8; i++) ctx.lineTo(cx - 8 + i * 2, my + (i % 2 ? 4 : -2));
    ctx.lineTo(cx + 8, my + 6); ctx.lineTo(cx - 8, my + 6); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  if (emo === 'scared' || emo === 'panic') { // keringat
    ctx.fillStyle = '#7ad0ff'; ctx.beginPath(); ctx.arc(cx + 15, hy - 6 + Math.sin(t * 6) * 1.5, 2.6, 0, 7); ctx.fill();
  }
  if (emo === 'sad') { ctx.fillStyle = '#7ad0ff'; ctx.beginPath(); ctx.arc(ex[1] + 2, ey + 9 + ((t * 8) % 6), 2, 0, 7); ctx.fill(); }
}
