import {AUDIO_SECONDS, DURATION_FRAMES, FPS} from './config';
import captionsRaw from './captions.json';

export type SceneId = 'hook' | 'wabah' | 'stasiun' | 'kota' | 'minimarket' | 'peta' | 'cliff';
export const SCENE_ORDER: SceneId[] = ['hook', 'wabah', 'stasiun', 'kota', 'minimarket', 'peta', 'cliff'];
export type Line = {tag: string; text: string; scene: SceneId};

export const LINES: Line[] = [
  {tag: 'mysterious', scene: 'hook', text: 'Bayangkan... suatu hari, sebuah kota yang biasanya ramai tiba-tiba berubah menjadi kota mati.'},
  {tag: 'calm', scene: 'hook', text: 'Awalnya, semuanya terlihat normal. Kendaraan masih berlalu-lalang, orang-orang masih bekerja, dan kereta masih mengangkut penumpang seperti biasa.'},
  {tag: 'tense', scene: 'wabah', text: 'Tapi semuanya berubah... ketika wabah misterius mulai menyebar.'},
  {tag: 'serious', scene: 'wabah', text: 'Rumah sakit mulai dipenuhi pasien. Orang-orang mulai menghilang. Dan beberapa orang yang sebelumnya sakit... tiba-tiba berubah menjadi sesuatu yang mengerikan.'},
  {tag: 'dramatic', scene: 'wabah', text: 'Zombie.'},
  {tag: 'concerned', scene: 'wabah', text: 'Dalam beberapa jam, kepanikan menyebar ke seluruh kota. Jalanan dipenuhi kendaraan yang ditinggalkan. Toko-toko mulai tutup. Dan stasiun KRL yang biasanya ramai... kini berubah menjadi tempat yang sangat berbahaya.'},
  {tag: 'tense', scene: 'stasiun', text: 'Bayangkan kamu sedang berada di dalam kereta ketika tiba-tiba listrik mati.'},
  {tag: 'confused', scene: 'stasiun', text: 'Kereta berhenti. Pintu tidak bisa dibuka secara normal. Sinyal komunikasi menghilang. Dan baterai HP-mu hanya tersisa satu persen.'},
  {tag: 'whispering', scene: 'stasiun', text: 'Kemudian... kamu mendengar suara dari gerbong sebelah.'},
  {tag: 'dramatic pause', scene: 'stasiun', text: 'Ada sesuatu yang sedang berjalan mendekat.'},
  {tag: 'afraid', scene: 'kota', text: 'Kamu berlari keluar stasiun dan menemukan kota sudah benar-benar kacau.'},
  {tag: 'serious', scene: 'kota', text: 'Mobil terbengkalai di jalan. Gedung-gedung kosong. Tidak ada lagi aktivitas seperti biasanya.'},
  {tag: 'thoughtful', scene: 'minimarket', text: 'Setelah berhasil bersembunyi di sebuah minimarket, kamu menemukan radio tua.'},
  {tag: 'radio static', scene: 'minimarket', text: 'Jika masih ada yang mendengar... jangan pergi ke pusat kota. Kami masih bertahan... tapi persediaan kami hampir habis.'},
  {tag: 'curious', scene: 'peta', text: 'Kamu kemudian menemukan sebuah peta dengan dua lokasi yang ditandai.'},
  {tag: 'dramatic', scene: 'peta', text: 'Lokasi pertama adalah rumah sakit. Mungkin di sana kamu bisa menemukan obat dan mengetahui asal mula wabah ini.'},
  {tag: 'tense', scene: 'peta', text: 'Lokasi kedua adalah pos evakuasi di pinggir kota. Katanya, masih ada kelompok manusia yang bertahan di sana.'},
  {tag: 'dramatic pause', scene: 'cliff', text: 'Tapi sebelum kamu memutuskan...'},
  {tag: 'whispering', scene: 'cliff', text: 'Dari ujung jalan, puluhan zombie mulai mendekat.'},
  {tag: 'urgent', scene: 'cliff', text: 'Sekarang kamu harus memilih.'},
  {tag: 'dramatic', scene: 'cliff', text: 'A... pergi ke rumah sakit untuk mencari obat.'},
  {tag: 'dramatic', scene: 'cliff', text: 'Atau B... menuju pos evakuasi untuk mencari manusia yang masih bertahan.'},
  {tag: 'curious', scene: 'cliff', text: 'Menurut kalian, pilihan mana yang harus diambil?'},
  {tag: 'whispering', scene: 'cliff', text: 'Tulis A atau B di komentar... karena pilihan kalian akan menentukan kelanjutan Part 2.'},
];

export type Word = {text: string; start: number; end: number; line: number};

// ---- 1) Perkiraan timing (dipakai kalau src/captions.json kosong) ----
const LEAD = 0.25;
const TAIL = 0.5;
const weight = (l: Line) => {
  let w = l.text.length;
  w += (l.text.match(/\.\.\./g) || []).length * 10;
  w += (l.text.match(/[.?!]/g) || []).length * 4;
  w += (l.text.match(/,/g) || []).length * 3;
  if (/pause/.test(l.tag)) w += 18;
  return w + 6;
};

const scriptWords = LINES.flatMap((l, line) => l.text.split(/\s+/).filter(Boolean).map((text) => ({text, line})));

function estimate() {
  const total = LINES.reduce((s, l) => s + weight(l), 0);
  const span = AUDIO_SECONDS - LEAD - TAIL;
  let acc = 0;
  const lineStart: number[] = [];
  const lineEnd: number[] = [];
  LINES.forEach((l) => {
    const w = weight(l);
    lineStart.push(LEAD + (acc / total) * span);
    acc += w;
    lineEnd.push(LEAD + ((acc - 6) / total) * span);
  });
  const words: Word[] = [];
  LINES.forEach((l, i) => {
    const ws = scriptWords.filter((x) => x.line === i);
    const wts = ws.map((x) => x.text.length + (/\.\.\.$/.test(x.text) ? 8 : /[.,?!]$/.test(x.text) ? 4 : 0));
    const sum = wts.reduce((a, b) => a + b, 0);
    let t = lineStart[i];
    ws.forEach((x, k) => {
      const d = ((lineEnd[i] - lineStart[i]) * wts[k]) / sum;
      words.push({text: x.text, start: t, end: t + d, line: i});
      t += d;
    });
  });
  return {words, lineStart};
}

// ---- 2) Timing dari Whisper (npm run transcribe -> src/captions.json) ----
function fromCaptions() {
  const caps = captionsRaw as any[];
  const W: {start: number; end: number}[] = [];
  for (const c of caps) {
    const t: string = c.text ?? '';
    if (!t.trim() || /^\[.*\]$/.test(t.trim())) continue;
    if (W.length === 0 || /^\s/.test(t)) W.push({start: c.startMs / 1000, end: c.endMs / 1000});
    else W[W.length - 1].end = c.endMs / 1000;
  }
  const Ns = scriptWords.length;
  const Nw = W.length;
  const startOf = (k: number) => W[Math.min(Nw - 1, Math.round((k * Nw) / Ns))].start;
  const words: Word[] = scriptWords.map((x, k) => ({
    text: x.text,
    line: x.line,
    start: startOf(k),
    end: k + 1 < Ns ? startOf(k + 1) : W[Nw - 1].end,
  }));
  const lineStart = LINES.map((_, i) => words.find((w) => w.line === i)!.start);
  return {words, lineStart};
}

const timing = (captionsRaw as any[]).length > 20 ? fromCaptions() : estimate();
export const WORDS = timing.words;
export const LINE_START = timing.lineStart; // detik
export const lineFrame = (i: number) => Math.round(LINE_START[i] * FPS);

// ---- Scene boundaries ----
const firstLine = (id: SceneId) => LINES.findIndex((l) => l.scene === id);
export const SCENES = SCENE_ORDER.map((id, i) => {
  const start = i === 0 ? 0 : lineFrame(firstLine(id));
  const next = i + 1 < SCENE_ORDER.length ? lineFrame(firstLine(SCENE_ORDER[i + 1])) : DURATION_FRAMES;
  return {id, start, end: next};
});

// ---- Subtitle chunks: 3-5 kata ----
export type Chunk = {words: Word[]; start: number; end: number};
export const CHUNKS: Chunk[] = (() => {
  const out: Chunk[] = [];
  let cur: Word[] = [];
  const flush = () => {
    if (cur.length) out.push({words: cur, start: cur[0].start, end: cur[cur.length - 1].end});
    cur = [];
  };
  WORDS.forEach((w, i) => {
    cur.push(w);
    const last = WORDS[i + 1]?.line !== w.line;
    if (last || cur.length >= 4 || /[.?!]$|\.\.\.$/.test(w.text) || (cur.length >= 3 && /,$/.test(w.text))) flush();
  });
  flush();
  return out;
})();
