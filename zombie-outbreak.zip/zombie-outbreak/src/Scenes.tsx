import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {FPS} from './config';
import {lineFrame} from './script';
import {CameraRig, Key} from './three/CameraRig';
import {Character, Walker, V3} from './three/Character';
import {World} from './three/world';
import {MapPoster, ShopSet, StationSet} from './three/sets';
import {Cinema, ChoiceUI} from './ui';
import {FONT} from './fonts';
import {rng} from './three/textures';

export type SP = {from: number; dur: number};
const ck = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const COLORS = ['#f2f2f2', '#ffd166', '#7bdff2', '#ffadad', '#caffbf', '#cdb4db'];

const Stage: React.FC<{sky: [string, string]; keys: Key[]; frame: number; linear?: boolean; children: React.ReactNode}> = ({sky, keys, frame, linear, children}) => {
  const {width, height} = useVideoConfig();
  return (
    <AbsoluteFill style={{background: `linear-gradient(${sky[0]}, ${sky[1]} 62%)`}}>
      <ThreeCanvas width={width} height={height} camera={{fov: 50, near: 0.1, far: 800, position: [0, 2, 10]}}>
        <CameraRig keys={keys} frame={frame} linear={linear} />
        {children}
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
const useS = ({from, dur}: SP) => {
  const f = useCurrentFrame();
  const at = (i: number, off = 0) => lineFrame(i) + Math.round(off * FPS) - from;
  return {f, dur, at};
};
const inc = (a: number, b: number) => (a < b ? b : a + 1);

/* ---------- 1. HOOK: kota hidup lalu mati ---------- */
export const SceneHook: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const b0 = dur - 170;
  const base = interpolate(f, [b0, dur - 55], [1, 0], ck);
  const flick = f > b0 - 20 && f < b0 + 70 ? (Math.sin(f * 1.9) > 0.2 ? 1 : 0.4) : 1;
  const power = base * flick;
  const night = power > 0.5 ? '#1d2740' : '#0c111c';
  const ts = spring({frame: f - (dur - 75), fps: FPS, config: {damping: 12, stiffness: 140}});
  const tint = power > 0.5 ? '#b8c0d8' : '#6d7385';
  const walkers: {a: V3; b: V3; ph: number; v: number}[] = [
    {a: [-12, 0, -9], b: [12, 0, -9], ph: 0.1, v: 1.4}, {a: [12, 0, -9.6], b: [-12, 0, -9.6], ph: 0.4, v: 1.3}, {a: [-12, 0, -10.2], b: [12, 0, -10.2], ph: 0.7, v: 1.5},
    {a: [-9.2, 0, -30], b: [-9.2, 0, 10], ph: 0.2, v: 1.3}, {a: [9.2, 0, 10], b: [9.2, 0, -30], ph: 0.5, v: 1.2}, {a: [-8.6, 0, 8], b: [-8.6, 0, -30], ph: 0.8, v: 1.4},
  ];
  return (
    <AbsoluteFill>
      <Stage sky={['#0b1020', night]} frame={f} keys={[{f: 0, pos: [4.5, 1.8, 22], look: [0, 5, -40]}, {f: dur, pos: [0, 30, 30], look: [0, 10, -110], fov: 55}]}>
        <World frame={f} power={power} day={0} abandoned={0} traffic={1} fogColor={night} fogNear={40} fogFar={300} led={power}>
          {walkers.map((w, i) => <Walker key={i} frame={f} a={w.a} b={w.b} speed={w.v} phase={w.ph} loop pose="walk" emotion="neutral" color={COLORS[i % 6]} tint={tint} seed={i} />)}
        </World>
      </Stage>
      <Cinema frame={f} vig={0.6} />
      {f > dur - 75 && (
        <AbsoluteFill style={{justifyContent: 'flex-start', alignItems: 'center', paddingTop: 260}}>
          <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 112, lineHeight: 1.05, textAlign: 'center', color: '#fff', transform: `scale(${0.5 + 0.5 * ts})`, opacity: ts, textShadow: '0 0 34px #c0261d, 0 6px 0 #7a1410'}}>
            SEMUA SUDAH<br /><span style={{color: '#ff3b30'}}>TERLAMBAT?</span>
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};

/* ---------- 2. WABAH: tracking shot pelarian ---------- */
export const SceneWabah: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const camZ = (x: number) => -58 + (86 * x) / dur;
  const hero: V3 = [0.4 + Math.sin(f / 40) * 0.8, 0, camZ(f) - 7.2];
  const crossings = [-30, -6, 14].map((z, i) => ({z, i, start: Math.round(((z + 18 + 58) / 86) * dur)}));
  const zomb: V3[] = [[-2, 0, -92], [3, 0, -105], [-4.5, 0, -118], [1.5, 0, -126], [5, 0, -98], [-1, 0, -140]];
  const tint = '#c5cbc0';
  return (
    <AbsoluteFill>
      <Stage sky={['#8f9a93', '#b9c0b6']} linear frame={f} keys={[{f: 0, pos: [0.6, 2.2, -58], look: [0.2, 1.6, -72]}, {f: dur, pos: [0.6, 2.2, 28], look: [0.2, 1.6, 14]}]}>
        <World frame={f} power={0.15} day={0.85} abandoned={0.6} fogColor="#aeb5ab" fogNear={12} fogFar={170} ambulance>
          <Character frame={f} pos={hero} pose="run" emotion="panic" view="front" color="#ffd166" tint={tint} res={3} />
          {crossings.map((c) => (
            <Walker key={c.i} frame={f} startFrame={c.start} a={[c.i % 2 ? 11 : -11, 0, c.z - 4]} b={[c.i % 2 ? -11 : 11, 0, c.z - 4]} speed={4.2} pose="run" emotion="scared" color={COLORS[c.i + 2]} tint={tint} />
          ))}
          <Walker frame={f} a={[-5, 0, camZ(0) - 18]} b={[-5, 0, 60]} speed={4.7} pose="run" emotion="scared" color="#ffadad" tint={tint} />
          <Walker frame={f} a={[5, 0, camZ(0) - 24]} b={[5, 0, 60]} speed={4.4} pose="run" emotion="panic" color="#caffbf" tint={tint} />
          {zomb.map((p, i) => <Walker key={i} frame={f} a={p} b={[p[0], 0, p[2] + 80]} speed={1.0} pose="zombie" emotion="zombie" tint="#9aa093" phase={i * 0.03} />)}
        </World>
      </Stage>
      <Cinema frame={f} vig={0.5} tint="#cfd6c8" />
    </AbsoluteFill>
  );
};

/* ---------- 3. STASIUN KRL ---------- */
export const SceneStasiun: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const power = interpolate(f, [at(6, 2.4), at(6, 3.3)], [1, 0], ck);
  const zOp = interpolate(f, [at(8, 1.2), at(9, 1.2)], [0, 1], ck);
  const tint = '#8e9a98';
  return (
    <AbsoluteFill>
      <Stage sky={['#0d1210', '#1a2220']} frame={f} keys={[{f: 0, pos: [-1.2, 1.7, 8], look: [0.5, 1.6, -8]}, {f: dur, pos: [1.0, 1.55, -2.0], look: [2.0, 1.5, -9]}]}>
        <StationSet frame={f} power={power} />
        <Character frame={f} pos={[2.0, 0, -8.6]} pose="hold" emotion="confused" view="front" hold="phone" color="#7bdff2" tint={tint} res={3} />
        <Character frame={f} pos={[-0.6, 0, -11]} pose="stand" emotion="scared" view="side" look={1} color="#ffadad" tint={tint} />
        <Character frame={f} pos={[-3.2, 0, -15]} pose="handsup" emotion="panic" view="front" color="#ffd166" tint={tint} />
        <Character frame={f} pos={[0.6, 0, -18]} pose="stand" emotion="shock" view="front" color="#caffbf" tint={tint} />
        <Character frame={f} pos={[-2, 0, -21]} pose="stand" emotion="sad" view="front" color="#cdb4db" tint={tint} />
        <Character frame={f} pos={[4.0, 0, -6.25]} pose="zombie" emotion="zombie" view="front" silhouette opacity={zOp} shadow={false} />
        <Character frame={f} pos={[4.0, 0, -19.0]} pose="zombie" emotion="zombie" view="front" silhouette opacity={zOp * 0.7} shadow={false} />
      </Stage>
      <Cinema frame={f} vig={0.7} tint="#9fb2ad" />
    </AbsoluteFill>
  );
};

/* ---------- 4. KOTA TERBENGKALAI ---------- */
export const SceneKota: React.FC<SP> = (sp) => {
  const {f, dur} = useS(sp);
  const tint = '#bcc2b8';
  return (
    <AbsoluteFill>
      <Stage sky={['#6d7770', '#9aa39a']} frame={f} keys={[{f: 0, pos: [-3, 1.8, 30], look: [0, 1.5, 10]}, {f: dur, pos: [1, 9, 20], look: [0, 4, -80]}]}>
        <World frame={f} power={0} day={0.6} abandoned={1} fogColor="#8d968d" fogNear={20} fogFar={200}>
          <Walker frame={f} a={[-12, 0, 12]} b={[10, 0, 12]} speed={4} pose="run" afterPose="stand" emotion="panic" color="#ffd166" tint={tint} res={3} />
          {[[2, -60], [-3, -75], [5, -95]].map(([x, z], i) => <Walker key={i} frame={f} a={[x, 0, z]} b={[x, 0, z + 60]} speed={0.9} pose="zombie" emotion="zombie" tint="#9aa093" phase={i * 0.05} />)}
        </World>
      </Stage>
      <Cinema frame={f} vig={0.55} tint="#c8cec2" />
    </AbsoluteFill>
  );
};

/* ---------- 5. MINIMARKET + RADIO ---------- */
export const SceneMini: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const k1 = Math.max(30, at(13, -0.8)), k2 = inc(k1, at(13, 1.8));
  const radio = interpolate(f, [at(12, 3), at(13, 0.3)], [0.15, 1], ck);
  const aOp = interpolate(f, [at(13, 0), at(13, 0.4)], [1, 0], ck);
  const bOp = interpolate(f, [at(13, 1.4), at(13, 1.9)], [0, 1], ck);
  const tint = '#aeb4aa';
  const keys: Key[] = [
    {f: 0, pos: [-18.6, 1.45, -7.6], look: [-11, 1.5, -7.4]},
    {f: k1, pos: [-17.6, 1.42, -7.5], look: [-11, 1.55, -7.2]},
    {f: k2, pos: [-16.2, 1.55, -4.6], look: [-16.2, 1.55, -2.0]},
    {f: inc(k2, dur), pos: [-16.2, 1.55, -4.0], look: [-16.2, 1.55, -2.0]},
  ];
  return (
    <AbsoluteFill>
      <Stage sky={['#7f887f', '#a7aea2']} frame={f} keys={keys}>
        <World frame={f} power={0} day={0.55} abandoned={1} fogColor="#98a198" fogNear={14} fogFar={170} skipLeft={[-24, 6]}>
          <ShopSet frame={f} radio={radio} />
          {[0.12, 0.02, 0.17, 0.95].map((ph, i) => (
            <Walker key={i} frame={f} a={[-9.3, 0, -20]} b={[-9.3, 0, 4]} speed={1} phase={ph} loop rotY={-Math.PI / 2} pose="zombie" emotion="zombie" tint="#9aa093" />
          ))}
          <Character frame={f} pos={[-14.6, 0, -6.4]} rotY={-Math.PI / 2} pose="stand" emotion="scared" view="side" look={1} color="#7bdff2" tint={tint} opacity={aOp} />
          <Character frame={f} pos={[-16.2, 0, -1.6]} rotY={Math.PI} pose="stand" emotion="shock" view="front" color="#7bdff2" tint={tint} opacity={bOp} res={3} />
        </World>
      </Stage>
      <Cinema frame={f} vig={0.65} tint="#b7beb0" />
    </AbsoluteFill>
  );
};

/* ---------- 6. PETA ---------- */
export const ScenePeta: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const hi = f >= at(16) ? 'B' : f >= at(15) ? 'A' : 'none';
  return (
    <AbsoluteFill>
      <Stage sky={['#7f887f', '#a7aea2']} frame={f} keys={[{f: 0, pos: [-15.2, 1.6, -7.5], look: [-21, 1.6, -7.5]}, {f: dur, pos: [-19.1, 1.65, -7.5], look: [-21, 1.65, -7.5], fov: 48}]}>
        <World frame={f} power={0} day={0.55} abandoned={1} fogColor="#98a198" fogNear={14} fogFar={170} skipLeft={[-24, 6]}>
          <ShopSet frame={f} radio={0.5} />
          <MapPoster frame={f} hi={hi} />
          <Character frame={f} pos={[-19.2, 0, -6.2]} rotY={Math.PI / 2} pose="point" emotion="confused" view="side" color="#7bdff2" tint="#aeb4aa" res={3} />
        </World>
      </Stage>
      <Cinema frame={f} vig={0.6} tint="#b7beb0" />
    </AbsoluteFill>
  );
};

/* ---------- 7. CLIFFHANGER ---------- */
export const SceneCliff: React.FC<SP> = (sp) => {
  const {f, dur, at} = useS(sp);
  const hordes = React.useMemo(() => { const r = rng(11); return Array.from({length: 26}, () => ({x: (r() - 0.5) * 12, z: -26 - r() * 95, v: 1.1 + r() * 0.5})); }, []);
  const dark = interpolate(f, [at(19, -0.4), at(19, 0.5)], [0, 1], ck);
  const panic = f > at(18) ? 'panic' : 'scared';
  const tint = '#cdb7aa';
  return (
    <AbsoluteFill>
      <Stage sky={['#3a2a28', '#7a4a3c']} frame={f} keys={[{f: 0, pos: [0, 1.9, 12], look: [0, 1.6, 0]}, {f: inc(0, at(18, 4.5)), pos: [0, 1.75, 4.6], look: [0, 1.7, 0]}, {f: inc(at(18, 4.5), dur), pos: [0, 1.75, 4.2], look: [0, 1.7, 0]}]}>
        <World frame={f} power={0} day={0.35} abandoned={1} fogColor="#6a5149" fogNear={15} fogFar={190}>
          <Character frame={f} pos={[0, 0, 0]} pose="hold" emotion={panic as any} view="front" hold="radio" color="#ffd166" tint={tint} res={3} />
          {hordes.map((h, i) => <Walker key={i} frame={f} a={[h.x, 0, h.z]} b={[h.x, 0, h.z + 90]} speed={h.v} pose="zombie" emotion="zombie" tint="#9a8f88" phase={i * 0.01} />)}
        </World>
      </Stage>
      <Cinema frame={f} vig={0.7} tint="#d9b7a6" />
      <AbsoluteFill style={{background: '#000', opacity: dark}} />
      {dark > 0.95 && <ChoiceUI f={f} tTitle={at(19, 0.2)} tA={at(20)} tB={at(21)} tCta={at(22)} tCta2={at(23)} />}
    </AbsoluteFill>
  );
};
