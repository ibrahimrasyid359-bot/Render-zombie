import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {DURATION_FRAMES, FPS} from './config';
import {lineFrame, SCENES} from './script';
import {FontGate, Subtitles} from './ui';
import {SceneCliff, SceneHook, SceneKota, SceneMini, ScenePeta, SceneStasiun, SceneWabah} from './Scenes';

const OVERLAP = 12;
const MAP: Record<string, React.FC<{from: number; dur: number}>> = {
  hook: SceneHook, wabah: SceneWabah, stasiun: SceneStasiun, kota: SceneKota, minimarket: SceneMini, peta: ScenePeta, cliff: SceneCliff,
};

const Fade: React.FC<{children: React.ReactNode; on: boolean}> = ({children, on}) => {
  const f = useCurrentFrame();
  const o = on ? interpolate(f, [0, OVERLAP], [0, 1], {extrapolateRight: 'clamp'}) : 1;
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

const sfx = (file: string, frame: number, vol: number, dur = 120) => (
  <Sequence key={`${file}${frame}`} from={Math.max(0, Math.round(frame))} durationInFrames={dur}>
    <Audio src={staticFile(`sfx/${file}`)} volume={vol} />
  </Sequence>
);

export const Main: React.FC = () => {
  const L = lineFrame;
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Audio src={staticFile('voiceover.mp3')} volume={1} />
      <Audio src={staticFile('sfx/music.mp3')} loop volume={(f) => interpolate(f, [0, 60, DURATION_FRAMES - 90, DURATION_FRAMES], [0, 0.13, 0.13, 0])} />
      <Audio src={staticFile('sfx/wind.mp3')} loop volume={0.1} />
      {sfx('poweroff.mp3', SCENES[0].end - 170, 0.5, 90)}
      {sfx('hit.mp3', L(4), 0.7)}
      {sfx('groan.mp3', L(4) + 12, 0.45, 90)}
      {sfx('poweroff.mp3', L(6) + 2.4 * FPS, 0.5, 90)}
      {sfx('groan.mp3', L(9) + 10, 0.5, 90)}
      {sfx('static.mp3', L(13), 0.3, 8 * FPS)}
      {sfx('hit.mp3', L(17), 0.6)}
      {sfx('groan.mp3', L(18), 0.5, 90)}
      {sfx('groan.mp3', L(18) + 40, 0.4, 90)}
      {sfx('pop.mp3', L(20), 0.6, 20)}
      {sfx('pop.mp3', L(21), 0.6, 20)}
      {sfx('pop.mp3', L(22), 0.6, 20)}
      <FontGate>
        {SCENES.map((s, i) => {
          const from = i === 0 ? 0 : s.start - OVERLAP;
          const C = MAP[s.id];
          return (
            <Sequence key={s.id} from={from} durationInFrames={s.end - from}>
              <Fade on={i > 0}><C from={from} dur={s.end - from} /></Fade>
            </Sequence>
          );
        })}
        <Subtitles />
      </FontGate>
    </AbsoluteFill>
  );
};
