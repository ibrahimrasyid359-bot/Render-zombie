export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const AUDIO_SECONDS = 122.83; // durasi voiceover.mp3
export const DURATION_FRAMES = Math.ceil(AUDIO_SECONDS * FPS) + 15;
